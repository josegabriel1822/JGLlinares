-- ============================================================================
-- JGL — Autoprueba de la lógica de pedidos e inventario.
-- 1) Ejecuta este archivo (crea la función de prueba).
-- 2) Luego ejecuta, en una consulta nueva:   select * from jgl_autoprueba();
-- Todas las líneas deben empezar con "OK". La prueba crea datos temporales y los
-- deshace al final: NO toca tus productos reales. (Solo se "gasta" un número de pedido.)
-- ============================================================================
CREATE OR REPLACE FUNCTION jgl_autoprueba() RETURNS SETOF text
LANGUAGE plpgsql AS $$
DECLARE
  res text[] := ARRAY[]::text[];
  a jsonb; b jsonb; c jsonb; d jsonb;
  ped_a text; ped_x text; ped_b text;
  st record; n integer; ok boolean; s text; i integer := 0; rechazados integer := 0;
  nok integer; nfalla integer;
BEGIN
  BEGIN
    -- Datos de prueba: un producto con tres variantes (stock 1, 5 y 0)
    INSERT INTO "Categoria"("id","slug","nombre") VALUES ('cat_tst','tst','Prueba');
    INSERT INTO "Producto"("id","slug","skuBase","nombre","descripcion","tipo","estado","precioCentimos","precioPromoCentimos","categoriaId")
    VALUES ('prod_tst','tst-producto','TST','Producto de prueba','x','POLO','PUBLICADO',10000,8000,'cat_tst');
    INSERT INTO "Variante"("id","productoId","talla","color","colorHex","sku","stock","reservado") VALUES
      ('var_tst_m','prod_tst','M','Negro','#000000','TST-M-N',1,0),
      ('var_tst_l','prod_tst','L','Negro','#000000','TST-L-N',5,0),
      ('var_tst_xl','prod_tst','XL','Negro','#000000','TST-XL-N',0,0);

    -- 1. Solicitud válida: el precio sale de la base (promoción S/ 80.00) y el stock NO baja
    a := jgl_crear_solicitud('[{"sku":"TST-M-N","cantidad":1}]'::jsonb, 'clave-prueba-0001');
    ped_a := a->>'id';
    SELECT "stock", "reservado" INTO st FROM "Variante" WHERE "sku" = 'TST-M-N';
    res := array_append(res, CASE WHEN (a->>'ok')::boolean AND (a->>'subtotalCentimos')::integer = 8000 AND st.stock = 1 AND st.reservado = 1
      THEN 'OK     ' ELSE 'FALLA  ' END || '1. Solicitud válida: precio tomado de la base; se reserva sin bajar el stock');

    -- 2. La última unidad no se asigna a dos clientes
    b := jgl_crear_solicitud('[{"sku":"TST-M-N","cantidad":1}]'::jsonb, 'clave-prueba-0002');
    res := array_append(res, CASE WHEN NOT (b->>'ok')::boolean AND b->'errores'->0->>'motivo' = 'sin_stock'
      THEN 'OK     ' ELSE 'FALLA  ' END || '2. La última unidad no se entrega a dos clientes');

    -- 3. Reintento con la misma clave: no duplica pedido ni reserva
    c := jgl_crear_solicitud('[{"sku":"TST-M-N","cantidad":1}]'::jsonb, 'clave-prueba-0001');
    SELECT count(*) INTO n FROM "Pedido" WHERE "claveIdempotencia" = 'clave-prueba-0001';
    SELECT "reservado" INTO st FROM "Variante" WHERE "sku" = 'TST-M-N';
    res := array_append(res, CASE WHEN (c->>'ok')::boolean AND (c->>'repetido')::boolean AND c->>'numero' = a->>'numero' AND n = 1 AND st.reservado = 1
      THEN 'OK     ' ELSE 'FALLA  ' END || '3. Doble clic o reintento: no se duplica el pedido ni la reserva');

    -- 4. Datos inválidos rechazados
    FOREACH s IN ARRAY ARRAY[
      '[{"sku":"TST-L-N","cantidad":0}]', '[{"sku":"TST-L-N","cantidad":-1}]', '[{"sku":"TST-L-N","cantidad":99}]',
      '[{"sku":"TST-L-N","cantidad":"2"}]', '[]', '{"a":1}', '[{"cantidad":1}]', '[{"sku":"TST-L-N","cantidad":1.5}]'
    ] LOOP
      i := i + 1;
      d := jgl_crear_solicitud(s::jsonb, 'clave-invalida-' || i);
      IF NOT (d->>'ok')::boolean THEN rechazados := rechazados + 1; END IF;
    END LOOP;
    res := array_append(res, CASE WHEN rechazados = 8 THEN 'OK     ' ELSE 'FALLA  ' END || '4. Cantidades y formatos inválidos son rechazados (' || rechazados || ' de 8)');

    -- 5. SKU inexistente y variante agotada
    a := jgl_crear_solicitud('[{"sku":"NO-EXISTE","cantidad":1}]'::jsonb, 'clave-prueba-0003');
    b := jgl_crear_solicitud('[{"sku":"TST-XL-N","cantidad":1}]'::jsonb, 'clave-prueba-0004');
    res := array_append(res, CASE WHEN NOT (a->>'ok')::boolean AND NOT (b->>'ok')::boolean THEN 'OK     ' ELSE 'FALLA  ' END || '5. SKU inexistente y variante agotada son rechazados');

    -- 6. Aceptar: el stock baja definitivamente y se libera la reserva
    d := jgl_aceptar_pedido(ped_a, 'admin-prueba');
    SELECT "stock", "reservado" INTO st FROM "Variante" WHERE "sku" = 'TST-M-N';
    SELECT count(*) INTO n FROM "MovimientoStock" WHERE "pedidoId" = ped_a AND "motivo" = 'VENTA';
    res := array_append(res, CASE WHEN (d->>'ok')::boolean AND st.stock = 0 AND st.reservado = 0 AND n = 1
      THEN 'OK     ' ELSE 'FALLA  ' END || '6. Al aceptar, el stock baja y queda en el historial');

    -- 7. No se puede aceptar dos veces
    d := jgl_aceptar_pedido(ped_a, 'admin-prueba');
    res := array_append(res, CASE WHEN NOT (d->>'ok')::boolean AND d->>'error' = 'estado_invalido' THEN 'OK     ' ELSE 'FALLA  ' END || '7. Un pedido no se puede aceptar dos veces');

    -- 8. Rechazar libera la reserva
    a := jgl_crear_solicitud('[{"sku":"TST-L-N","cantidad":2}]'::jsonb, 'clave-prueba-0005');
    SELECT "reservado" INTO st FROM "Variante" WHERE "sku" = 'TST-L-N';
    n := st.reservado;
    d := jgl_rechazar_pedido(a->>'id', 'admin-prueba', 'prueba');
    SELECT "stock", "reservado" INTO st FROM "Variante" WHERE "sku" = 'TST-L-N';
    res := array_append(res, CASE WHEN n = 2 AND (d->>'ok')::boolean AND st.reservado = 0 AND st.stock = 5
      THEN 'OK     ' ELSE 'FALLA  ' END || '8. Rechazar libera las unidades reservadas');

    -- 9. Una reserva vencida se libera sola
    a := jgl_crear_solicitud('[{"sku":"TST-L-N","cantidad":2}]'::jsonb, 'clave-prueba-0006');
    ped_x := a->>'id';
    UPDATE "Pedido" SET "reservaVenceEn" = timezone('utc', now()) - interval '1 hour' WHERE "id" = ped_x;
    n := jgl_expirar_reservas();
    SELECT "reservado" INTO st FROM "Variante" WHERE "sku" = 'TST-L-N';
    res := array_append(res, CASE WHEN n >= 1 AND st.reservado = 0 AND (SELECT "estado"::text FROM "Pedido" WHERE "id" = ped_x) = 'CANCELADO'
      THEN 'OK     ' ELSE 'FALLA  ' END || '9. La reserva vencida se cancela sola y libera el stock');

    -- 10. Cancelar un pedido ya aceptado devuelve el stock
    d := jgl_cancelar_pedido(ped_a, 'admin-prueba', 'prueba');
    SELECT "stock", "reservado" INTO st FROM "Variante" WHERE "sku" = 'TST-M-N';
    SELECT count(*) INTO n FROM "MovimientoStock" WHERE "pedidoId" = ped_a AND "motivo" = 'DEVOLUCION';
    res := array_append(res, CASE WHEN (d->>'ok')::boolean AND st.stock = 1 AND st.reservado = 0 AND n = 1
      AND (SELECT "estado"::text FROM "Pedido" WHERE "id" = ped_a) = 'CANCELADO'
      THEN 'OK     ' ELSE 'FALLA  ' END || '10. Cancelar un pedido aceptado devuelve el stock');

    -- 11. Ciclo completo de estados y transiciones inválidas
    a := jgl_crear_solicitud('[{"sku":"TST-L-N","cantidad":1}]'::jsonb, 'clave-prueba-0007');
    ped_b := a->>'id';
    d := jgl_aceptar_pedido(ped_b, 'admin-prueba');                       ok := (d->>'ok')::boolean;
    d := jgl_cambiar_estado_pedido(ped_b, 'PREPARANDO', 'admin-prueba');  ok := ok AND (d->>'ok')::boolean;
    d := jgl_cambiar_estado_pedido(ped_b, 'ENVIADO', 'admin-prueba');     ok := ok AND (d->>'ok')::boolean;
    d := jgl_cambiar_estado_pedido(ped_b, 'ENTREGADO', 'admin-prueba');   ok := ok AND (d->>'ok')::boolean;
    d := jgl_cambiar_estado_pedido(ped_b, 'PREPARANDO', 'admin-prueba');  ok := ok AND NOT (d->>'ok')::boolean;
    d := jgl_cancelar_pedido(ped_b, 'admin-prueba', NULL);                ok := ok AND NOT (d->>'ok')::boolean;
    res := array_append(res, CASE WHEN ok THEN 'OK     ' ELSE 'FALLA  ' END || '11. Estados: Aceptado, Preparando, Enviado, Entregado; no se retrocede ni se cancela un entregado');

    -- 12. La base impide stock negativo
    ok := false;
    BEGIN
      UPDATE "Variante" SET "stock" = -1 WHERE "sku" = 'TST-L-N';
    EXCEPTION WHEN check_violation THEN
      ok := true;
    END;
    res := array_append(res, CASE WHEN ok THEN 'OK     ' ELSE 'FALLA  ' END || '12. La base de datos rechaza el stock negativo');

    -- 13. Ajuste de stock: no puede quedar por debajo de lo reservado
    a := jgl_crear_solicitud('[{"sku":"TST-L-N","cantidad":3}]'::jsonb, 'clave-prueba-0008');
    d := jgl_ajustar_stock('TST-L-N', 2, 'admin-prueba');
    ok := NOT (d->>'ok')::boolean;
    d := jgl_ajustar_stock('TST-L-N', 10, 'admin-prueba');
    SELECT "stock" INTO st FROM "Variante" WHERE "sku" = 'TST-L-N';
    SELECT count(*) INTO n FROM "MovimientoStock" WHERE "varianteId" = 'var_tst_l' AND "motivo" = 'AJUSTE';
    res := array_append(res, CASE WHEN ok AND (d->>'ok')::boolean AND st.stock = 10 AND n >= 1 THEN 'OK     ' ELSE 'FALLA  ' END || '13. Ajustar stock: no baja de lo reservado y queda en el historial');

    -- 14. Registro de acciones del administrador
    SELECT count(*) INTO n FROM "RegistroAdmin" WHERE "adminId" = 'admin-prueba' AND "accion" = 'ACEPTAR_PEDIDO';
    res := array_append(res, CASE WHEN n >= 1 THEN 'OK     ' ELSE 'FALLA  ' END || '14. Las acciones del administrador quedan registradas');

    -- 15. Ninguna variante quedó con cifras imposibles
    SELECT count(*) INTO n FROM "Variante" WHERE "stock" < 0 OR "reservado" < 0 OR "reservado" > "stock";
    res := array_append(res, CASE WHEN n = 0 THEN 'OK     ' ELSE 'FALLA  ' END || '15. Stock y reservas siempre coherentes');

    -- 16. Estas funciones no se pueden llamar desde la API pública
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      ok := NOT has_function_privilege('anon', 'jgl_crear_solicitud(jsonb,text,integer)', 'EXECUTE')
        AND NOT has_function_privilege('anon', 'jgl_aceptar_pedido(text,text)', 'EXECUTE')
        AND NOT has_function_privilege('anon', 'jgl_ajustar_stock(text,integer,text)', 'EXECUTE');
      res := array_append(res, CASE WHEN ok THEN 'OK     ' ELSE 'FALLA  ' END || '16. Un visitante anónimo no puede ejecutar estas funciones');
    ELSE
      res := array_append(res, 'INFO   16. No existe el rol "anon" en esta base; no aplica');
    END IF;

    -- Deshacer TODOS los datos de prueba
    RAISE EXCEPTION 'JGL_ROLLBACK';
  EXCEPTION WHEN OTHERS THEN
    IF SQLERRM <> 'JGL_ROLLBACK' THEN
      res := array_append(res, 'FALLA  ERROR inesperado: ' || SQLERRM);
    END IF;
  END;

  SELECT count(*) FILTER (WHERE x LIKE 'OK%'), count(*) FILTER (WHERE x LIKE 'FALLA%') INTO nok, nfalla FROM unnest(res) x;
  RETURN QUERY SELECT unnest(res);
  RETURN NEXT 'RESUMEN: ' || nok || ' pruebas OK, ' || nfalla || ' con fallas. Los datos de prueba se deshicieron.';
END $$;

-- Esta función de prueba tampoco se puede llamar desde la API pública.
DO $$
DECLARE f record;
BEGIN
  FOR f IN
    SELECT p.oid::regprocedure AS firma
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname LIKE 'jgl\_%'
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', f.firma);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon', f.firma);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM authenticated', f.firma);
    END IF;
  END LOOP;
END $$;
