-- ============================================================================
-- JGL — Almacén de fotos de productos (Supabase Storage). Ejecuta una vez.
-- Bucket PÚBLICO de solo lectura (las fotos de la tienda las ve cualquiera, pero NO se puede
-- listar ni subir desde fuera). Las subidas las hace solo el servidor, tras comprobar
-- que quien sube es administrador, que el archivo es una imagen real y pesa hasta 5 MB.
-- Si este archivo diera error, crea el bucket a mano: Storage > New bucket > nombre "productos",
-- marca "Public bucket", tamaño máximo 5 MB y tipos image/jpeg, image/png, image/webp.
-- ============================================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('productos', 'productos', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/webp'])
ON CONFLICT (id) DO NOTHING;
