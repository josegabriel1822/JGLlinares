-- ============================================================================
-- JGL — Límite de solicitudes por visitante (evita que alguien llene la tienda de
-- reservas falsas). Ejecútalo después de pedidos.sql. Es seguro repetirlo.
-- Guarda solo un HASH de la IP (nunca la IP) y la cuenta de intentos de la última hora.
-- Una sola fila por visitante (se reutiliza); no hace falta borrar nada.
-- ============================================================================
CREATE TABLE IF NOT EXISTS "LimiteSolicitud" (
  "clave"   TEXT NOT NULL,
  "cuenta"  INTEGER NOT NULL,
  "venceEn" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "LimiteSolicitud_pkey" PRIMARY KEY ("clave")
);
ALTER TABLE "LimiteSolicitud" ENABLE ROW LEVEL SECURITY;

-- Devuelve true si el visitante aún puede intentar; false si superó el máximo en la ventana.
CREATE OR REPLACE FUNCTION jgl_limitar(p_clave text, p_max integer, p_segundos integer) RETURNS boolean
LANGUAGE plpgsql AS $$
DECLARE v_cuenta integer; v_ahora timestamp := timezone('utc', now());
BEGIN
  IF p_clave IS NULL OR length(p_clave) < 16 OR p_max < 1 OR p_segundos < 1 THEN RETURN false; END IF;
  INSERT INTO "LimiteSolicitud"("clave","cuenta","venceEn")
  VALUES (p_clave, 1, v_ahora + make_interval(secs => p_segundos))
  ON CONFLICT ("clave") DO UPDATE SET
    "cuenta"  = CASE WHEN "LimiteSolicitud"."venceEn" < v_ahora THEN 1 ELSE "LimiteSolicitud"."cuenta" + 1 END,
    "venceEn" = CASE WHEN "LimiteSolicitud"."venceEn" < v_ahora THEN v_ahora + make_interval(secs => p_segundos) ELSE "LimiteSolicitud"."venceEn" END
  WHERE "LimiteSolicitud"."clave" = EXCLUDED."clave"
  RETURNING "cuenta" INTO v_cuenta;
  RETURN v_cuenta <= p_max;
END $$;

-- Autocomprobación (se deshace sola): debe devolver  true,true,true,false,false
CREATE OR REPLACE FUNCTION jgl_autoprueba_limite() RETURNS text
LANGUAGE plpgsql AS $$
DECLARE r text := '';
BEGIN
  BEGIN
    r := (jgl_limitar('huella-de-prueba-0000000001', 3, 3600))::text;
    r := r || ',' || (jgl_limitar('huella-de-prueba-0000000001', 3, 3600))::text;
    r := r || ',' || (jgl_limitar('huella-de-prueba-0000000001', 3, 3600))::text;
    r := r || ',' || (jgl_limitar('huella-de-prueba-0000000001', 3, 3600))::text;
    r := r || ',' || (jgl_limitar('huella-de-prueba-0000000001', 3, 3600))::text;
    RAISE EXCEPTION 'JGL_ROLLBACK';
  EXCEPTION WHEN OTHERS THEN
    IF SQLERRM <> 'JGL_ROLLBACK' THEN r := 'ERROR: ' || SQLERRM; END IF;
  END;
  RETURN r;
END $$;

DO $$
DECLARE f record;
BEGIN
  FOR f IN
    SELECT p.oid::regprocedure AS firma
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname LIKE 'jgl\_%'
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', f.firma);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon', f.firma);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM authenticated', f.firma);
    END IF;
  END LOOP;
END $$;
