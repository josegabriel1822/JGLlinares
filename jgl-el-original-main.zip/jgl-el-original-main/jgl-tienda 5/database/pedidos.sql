-- ============================================================================
-- JGL — Lógica de pedidos e inventario dentro de la base de datos (PostgreSQL).
-- Ejecútalo DESPUÉS de schema.sql y seed.sql. Es seguro repetirlo.
--
-- Por qué aquí: las operaciones de stock se hacen DENTRO de la base de datos,
-- con bloqueos de fila, para que dos clientes nunca obtengan la misma última
-- unidad, aunque pidan en el mismo instante.
--
-- Cómo funciona el stock:
--   disponible = stock - reservado
--   1) El cliente pide  -> solicitud PENDIENTE y se RESERVA (reservado sube). El stock no baja.
--   2) El admin ACEPTA  -> el stock baja definitivamente y se libera la reserva.
--   3) RECHAZAR / CANCELAR / vencer la reserva -> se libera (o se devuelve si ya estaba aceptado).
--
-- movimiento.delta: cambio en "reservado" para RESERVA y LIBERACION;
--                   cambio en "stock" para VENTA, DEVOLUCION y AJUSTE.
-- Estas funciones NO se pueden llamar desde la API pública: solo desde el servidor.
-- ============================================================================

-- ---------- Respuesta estándar de un pedido ----------
CREATE OR REPLACE FUNCTION jgl_respuesta_pedido(p_id text) RETURNS jsonb
LANGUAGE sql STABLE AS $$
  SELECT jsonb_build_object(
    'ok', true,
    'id', p."id",
    'numero', p."numero",
    'estado', p."estado",
    'subtotalCentimos', p."subtotalCentimos",
    'items', COALESCE((
      SELECT jsonb_agg(jsonb_build_object(
        'nombre', i."nombre", 'talla', i."talla", 'color', i."color",
        'cantidad', i."cantidad", 'precioUnitCentimos', i."precioUnitCentimos"
      ) ORDER BY i."nombre", i."talla", i."color")
      FROM "PedidoItem" i WHERE i."pedidoId" = p."id"
    ), '[]'::jsonb)
  )
  FROM "Pedido" p WHERE p."id" = p_id;
$$;

-- ---------- Liberar la reserva de un pedido (rechazo, cancelación o vencimiento) ----------
CREATE OR REPLACE FUNCTION jgl_liberar_reserva(p_pedido text, p_admin text) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE it record;
BEGIN
  FOR it IN
    SELECT i."varianteId" AS vid, i."cantidad" AS cant
    FROM "PedidoItem" i JOIN "Variante" v ON v."id" = i."varianteId"
    WHERE i."pedidoId" = p_pedido
    ORDER BY v."sku"
  LOOP
    UPDATE "Variante" SET "reservado" = GREATEST("reservado" - it.cant, 0) WHERE "id" = it.vid;
    INSERT INTO "MovimientoStock"("id","varianteId","pedidoId","adminId","delta","motivo")
    VALUES (gen_random_uuid()::text, it.vid, p_pedido, p_admin, -it.cant, 'LIBERACION');
  END LOOP;
END $$;

-- ---------- Devolver al stock un pedido ya aceptado que se cancela ----------
CREATE OR REPLACE FUNCTION jgl_devolver_stock(p_pedido text, p_admin text) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE it record;
BEGIN
  FOR it IN
    SELECT i."varianteId" AS vid, i."cantidad" AS cant
    FROM "PedidoItem" i JOIN "Variante" v ON v."id" = i."varianteId"
    WHERE i."pedidoId" = p_pedido
    ORDER BY v."sku"
  LOOP
    UPDATE "Variante" SET "stock" = "stock" + it.cant WHERE "id" = it.vid;
    INSERT INTO "MovimientoStock"("id","varianteId","pedidoId","adminId","delta","motivo")
    VALUES (gen_random_uuid()::text, it.vid, p_pedido, p_admin, it.cant, 'DEVOLUCION');
  END LOOP;
END $$;

-- ---------- Vencer las reservas que nadie aceptó a tiempo ----------
CREATE OR REPLACE FUNCTION jgl_expirar_reservas() RETURNS integer
LANGUAGE plpgsql AS $$
DECLARE ped record; n integer := 0;
BEGIN
  FOR ped IN
    SELECT "id" FROM "Pedido"
    WHERE "estado" = 'PENDIENTE' AND "reservaVenceEn" IS NOT NULL
      AND "reservaVenceEn" < timezone('utc', now())
    ORDER BY "id"
    FOR UPDATE SKIP LOCKED
  LOOP
    PERFORM jgl_liberar_reserva(ped."id", NULL);
    UPDATE "Pedido" SET "estado" = 'CANCELADO', "cerradoPor" = 'expiracion',
           "actualizadoEn" = timezone('utc', now())
    WHERE "id" = ped."id";
    n := n + 1;
  END LOOP;
  RETURN n;
END $$;

-- ---------- Crear una solicitud de pedido ----------
-- p_items: [{"sku":"POLO-PREMIUM-A-M-NEGRO","cantidad":2}, ...]
-- p_clave: identificador único del intento (evita duplicados por doble clic o reintentos).
-- El precio SIEMPRE sale de la base de datos; lo que envíe el navegador no cuenta.
CREATE OR REPLACE FUNCTION jgl_crear_solicitud(p_items jsonb, p_clave text, p_horas integer DEFAULT 24)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE
  e jsonb;
  v_map jsonb := '{}'::jsonb;
  l record;
  r record;
  v_existente record;
  v_lineas jsonb := '[]'::jsonb;
  v_errores jsonb := '[]'::jsonb;
  v_precio integer;
  v_subtotal integer := 0;
  v_pedido_id text;
  v_cant integer;
BEGIN
  IF p_clave IS NULL OR length(p_clave) < 8 OR length(p_clave) > 100 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'clave_invalida');
  END IF;
  IF p_horas IS NULL OR p_horas < 1 OR p_horas > 168 THEN p_horas := 24; END IF;
  IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array'
     OR jsonb_array_length(p_items) < 1 OR jsonb_array_length(p_items) > 20 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'items_invalidos');
  END IF;

  -- Reintento del mismo pedido: se devuelve el que ya existe, sin duplicar ni reservar de nuevo.
  SELECT "id" INTO v_existente FROM "Pedido" WHERE "claveIdempotencia" = p_clave;
  IF FOUND THEN
    RETURN jgl_respuesta_pedido(v_existente."id") || jsonb_build_object('repetido', true);
  END IF;

  -- Validación estricta de cada línea (tipos, rangos) y suma de líneas repetidas.
  FOR e IN SELECT x.value FROM jsonb_array_elements(p_items) x LOOP
    IF jsonb_typeof(e) IS DISTINCT FROM 'object'
       OR jsonb_typeof(e->'sku') IS DISTINCT FROM 'string'
       OR jsonb_typeof(e->'cantidad') IS DISTINCT FROM 'number'
       OR COALESCE(length(e->>'sku'), 0) NOT BETWEEN 1 AND 100
       OR COALESCE(e->>'cantidad', 'x') !~ '^[0-9]{1,3}$' THEN
      RETURN jsonb_build_object('ok', false, 'error', 'items_invalidos');
    END IF;
    IF (e->>'cantidad')::integer < 1 THEN
      RETURN jsonb_build_object('ok', false, 'error', 'items_invalidos');
    END IF;
    v_cant := COALESCE((v_map->>(e->>'sku'))::integer, 0) + (e->>'cantidad')::integer;
    IF v_cant > 10 THEN
      RETURN jsonb_build_object('ok', false, 'error', 'cantidad_invalida');
    END IF;
    v_map := jsonb_set(v_map, ARRAY[e->>'sku'], to_jsonb(v_cant), true);
  END LOOP;

  -- Libera primero las reservas vencidas, para que el stock disponible esté al día.
  PERFORM jgl_expirar_reservas();

  -- Paso 1: bloquear cada variante (siempre en el mismo orden, para evitar bloqueos cruzados) y validar.
  FOR l IN SELECT k.key AS sku, (k.value)::text::integer AS cantidad FROM jsonb_each(v_map) k ORDER BY k.key LOOP
    SELECT v."id" AS vid, v."stock" AS stock, v."reservado" AS reservado, v."activo" AS activo,
           v."talla" AS talla, v."color" AS color, pr."nombre" AS nombre, pr."estado" AS estado,
           pr."proximamente" AS proximamente, pr."precioCentimos" AS precio, pr."precioPromoCentimos" AS promo
      INTO r
      FROM "Variante" v JOIN "Producto" pr ON pr."id" = v."productoId"
     WHERE v."sku" = l.sku
       FOR UPDATE OF v;
    IF NOT FOUND THEN
      v_errores := v_errores || jsonb_build_object('sku', l.sku, 'motivo', 'no_disponible', 'disponible', 0);
    ELSIF NOT r.activo OR r.estado::text <> 'PUBLICADO' OR r.proximamente OR r.precio IS NULL THEN
      v_errores := v_errores || jsonb_build_object('sku', l.sku, 'motivo', 'no_disponible', 'disponible', 0);
    ELSIF r.stock - r.reservado < l.cantidad THEN
      v_errores := v_errores || jsonb_build_object('sku', l.sku, 'motivo', 'sin_stock', 'disponible', GREATEST(r.stock - r.reservado, 0));
    ELSE
      v_precio := CASE WHEN r.promo IS NOT NULL AND r.promo < r.precio THEN r.promo ELSE r.precio END;
      v_lineas := v_lineas || jsonb_build_object('vid', r.vid, 'nombre', r.nombre, 'talla', r.talla,
                                                 'color', r.color, 'cantidad', l.cantidad, 'precio', v_precio);
      v_subtotal := v_subtotal + v_precio * l.cantidad;
    END IF;
  END LOOP;

  IF jsonb_array_length(v_errores) > 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'sin_stock', 'errores', v_errores);
  END IF;

  -- Paso 2: crear el pedido. Si otra petición con la misma clave llegó al mismo tiempo, se devuelve esa.
  v_pedido_id := gen_random_uuid()::text;
  BEGIN
    INSERT INTO "Pedido"("id","claveIdempotencia","subtotalCentimos","reservaVenceEn")
    VALUES (v_pedido_id, p_clave, v_subtotal, timezone('utc', now()) + make_interval(hours => p_horas));
  EXCEPTION WHEN unique_violation THEN
    SELECT "id" INTO v_existente FROM "Pedido" WHERE "claveIdempotencia" = p_clave;
    RETURN jgl_respuesta_pedido(v_existente."id") || jsonb_build_object('repetido', true);
  END;

  FOR l IN SELECT y.value AS j FROM jsonb_array_elements(v_lineas) y LOOP
    UPDATE "Variante" SET "reservado" = "reservado" + (l.j->>'cantidad')::integer WHERE "id" = l.j->>'vid';
    INSERT INTO "PedidoItem"("id","pedidoId","varianteId","nombre","talla","color","precioUnitCentimos","cantidad")
    VALUES (gen_random_uuid()::text, v_pedido_id, l.j->>'vid', l.j->>'nombre', l.j->>'talla', l.j->>'color',
            (l.j->>'precio')::integer, (l.j->>'cantidad')::integer);
    INSERT INTO "MovimientoStock"("id","varianteId","pedidoId","delta","motivo")
    VALUES (gen_random_uuid()::text, l.j->>'vid', v_pedido_id, (l.j->>'cantidad')::integer, 'RESERVA');
  END LOOP;

  RETURN jgl_respuesta_pedido(v_pedido_id);
END $$;

-- ---------- ACEPTAR: el stock baja definitivamente ----------
CREATE OR REPLACE FUNCTION jgl_aceptar_pedido(p_id text, p_admin text) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE ped record; it record; n integer;
BEGIN
  IF p_admin IS NULL OR length(p_admin) = 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'admin_requerido');
  END IF;
  PERFORM jgl_expirar_reservas();
  SELECT "id", "estado" INTO ped FROM "Pedido" WHERE "id" = p_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'error', 'no_existe'); END IF;
  IF ped."estado"::text <> 'PENDIENTE' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'estado_invalido', 'estado', ped."estado"::text);
  END IF;

  FOR it IN
    SELECT i."varianteId" AS vid, i."cantidad" AS cant
    FROM "PedidoItem" i JOIN "Variante" v ON v."id" = i."varianteId"
    WHERE i."pedidoId" = p_id ORDER BY v."sku"
  LOOP
    UPDATE "Variante" SET "stock" = "stock" - it.cant, "reservado" = "reservado" - it.cant
     WHERE "id" = it.vid AND "reservado" >= it.cant AND "stock" >= it.cant;
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n = 0 THEN RAISE EXCEPTION 'inconsistencia_stock'; END IF;
    INSERT INTO "MovimientoStock"("id","varianteId","pedidoId","adminId","delta","motivo")
    VALUES (gen_random_uuid()::text, it.vid, p_id, p_admin, -it.cant, 'VENTA');
  END LOOP;

  UPDATE "Pedido" SET "estado" = 'ACEPTADO', "actualizadoEn" = timezone('utc', now()) WHERE "id" = p_id;
  INSERT INTO "RegistroAdmin"("id","adminId","accion","entidad","entidadId")
  VALUES (gen_random_uuid()::text, p_admin, 'ACEPTAR_PEDIDO', 'Pedido', p_id);
  RETURN jsonb_build_object('ok', true, 'estado', 'ACEPTADO');
END $$;

-- ---------- RECHAZAR: se libera la reserva ----------
CREATE OR REPLACE FUNCTION jgl_rechazar_pedido(p_id text, p_admin text, p_nota text DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE ped record;
BEGIN
  IF p_admin IS NULL OR length(p_admin) = 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'admin_requerido');
  END IF;
  SELECT "id", "estado" INTO ped FROM "Pedido" WHERE "id" = p_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'error', 'no_existe'); END IF;
  IF ped."estado"::text <> 'PENDIENTE' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'estado_invalido', 'estado', ped."estado"::text);
  END IF;
  PERFORM jgl_liberar_reserva(p_id, p_admin);
  UPDATE "Pedido" SET "estado" = 'RECHAZADO', "cerradoPor" = 'admin', "notaAdmin" = left(p_nota, 500),
         "actualizadoEn" = timezone('utc', now()) WHERE "id" = p_id;
  INSERT INTO "RegistroAdmin"("id","adminId","accion","entidad","entidadId","detalle")
  VALUES (gen_random_uuid()::text, p_admin, 'RECHAZAR_PEDIDO', 'Pedido', p_id, left(p_nota, 500));
  RETURN jsonb_build_object('ok', true, 'estado', 'RECHAZADO');
END $$;

-- ---------- CANCELAR: libera la reserva (pendiente) o devuelve el stock (aceptado o en preparación) ----------
CREATE OR REPLACE FUNCTION jgl_cancelar_pedido(p_id text, p_admin text, p_nota text DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE ped record;
BEGIN
  IF p_admin IS NULL OR length(p_admin) = 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'admin_requerido');
  END IF;
  SELECT "id", "estado" INTO ped FROM "Pedido" WHERE "id" = p_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'error', 'no_existe'); END IF;
  IF ped."estado"::text = 'PENDIENTE' THEN
    PERFORM jgl_liberar_reserva(p_id, p_admin);
  ELSIF ped."estado"::text IN ('ACEPTADO', 'PREPARANDO') THEN
    PERFORM jgl_devolver_stock(p_id, p_admin);
  ELSE
    RETURN jsonb_build_object('ok', false, 'error', 'estado_invalido', 'estado', ped."estado"::text);
  END IF;
  UPDATE "Pedido" SET "estado" = 'CANCELADO', "cerradoPor" = 'admin', "notaAdmin" = left(p_nota, 500),
         "actualizadoEn" = timezone('utc', now()) WHERE "id" = p_id;
  INSERT INTO "RegistroAdmin"("id","adminId","accion","entidad","entidadId","detalle")
  VALUES (gen_random_uuid()::text, p_admin, 'CANCELAR_PEDIDO', 'Pedido', p_id, left(p_nota, 500));
  RETURN jsonb_build_object('ok', true, 'estado', 'CANCELADO');
END $$;

-- ---------- Avanzar el estado: ACEPTADO -> PREPARANDO -> ENVIADO -> ENTREGADO ----------
CREATE OR REPLACE FUNCTION jgl_cambiar_estado_pedido(p_id text, p_nuevo text, p_admin text) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE ped record; v_requerido text;
BEGIN
  IF p_admin IS NULL OR length(p_admin) = 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'admin_requerido');
  END IF;
  v_requerido := CASE p_nuevo WHEN 'PREPARANDO' THEN 'ACEPTADO' WHEN 'ENVIADO' THEN 'PREPARANDO' WHEN 'ENTREGADO' THEN 'ENVIADO' ELSE NULL END;
  IF v_requerido IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'estado_no_permitido');
  END IF;
  SELECT "id", "estado" INTO ped FROM "Pedido" WHERE "id" = p_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'error', 'no_existe'); END IF;
  IF ped."estado"::text <> v_requerido THEN
    RETURN jsonb_build_object('ok', false, 'error', 'estado_invalido', 'estado', ped."estado"::text);
  END IF;
  UPDATE "Pedido" SET "estado" = p_nuevo::"EstadoPedido", "actualizadoEn" = timezone('utc', now()) WHERE "id" = p_id;
  INSERT INTO "RegistroAdmin"("id","adminId","accion","entidad","entidadId","detalle")
  VALUES (gen_random_uuid()::text, p_admin, 'CAMBIAR_ESTADO_PEDIDO', 'Pedido', p_id, p_nuevo);
  RETURN jsonb_build_object('ok', true, 'estado', p_nuevo);
END $$;

-- ---------- Ajustar el stock de una variante (conteo físico, ingreso de mercadería) ----------
CREATE OR REPLACE FUNCTION jgl_ajustar_stock(p_sku text, p_nuevo integer, p_admin text) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE v record;
BEGIN
  IF p_admin IS NULL OR length(p_admin) = 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'admin_requerido');
  END IF;
  IF p_nuevo IS NULL OR p_nuevo < 0 OR p_nuevo > 100000 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'cantidad_invalida');
  END IF;
  SELECT "id", "stock", "reservado" INTO v FROM "Variante" WHERE "sku" = p_sku FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'error', 'no_existe'); END IF;
  IF p_nuevo < v."reservado" THEN
    RETURN jsonb_build_object('ok', false, 'error', 'menor_que_reservado', 'reservado', v."reservado");
  END IF;
  UPDATE "Variante" SET "stock" = p_nuevo WHERE "id" = v."id";
  INSERT INTO "MovimientoStock"("id","varianteId","adminId","delta","motivo")
  VALUES (gen_random_uuid()::text, v."id", p_admin, p_nuevo - v."stock", 'AJUSTE');
  INSERT INTO "RegistroAdmin"("id","adminId","accion","entidad","entidadId","detalle")
  VALUES (gen_random_uuid()::text, p_admin, 'AJUSTAR_STOCK', 'Variante', v."id", p_sku || ': ' || v."stock" || ' -> ' || p_nuevo);
  RETURN jsonb_build_object('ok', true, 'stock', p_nuevo);
END $$;

-- ---------- SEGURIDAD: estas funciones solo las puede ejecutar el servidor ----------
DO $$
DECLARE f record;
BEGIN
  FOR f IN
    SELECT p.oid::regprocedure AS firma
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname LIKE 'jgl\_%'
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', f.firma);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon', f.firma);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM authenticated', f.firma);
    END IF;
  END LOOP;
END $$;
