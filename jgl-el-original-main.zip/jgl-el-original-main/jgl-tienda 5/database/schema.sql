-- ============================================================================
-- JGL — Base de datos v2 (PostgreSQL). Pégalo completo en el editor SQL de
-- Supabase o Neon y ejecútalo UNA sola vez, en una base de datos vacía.
-- Usa esta vía O "npm run db:migrar" (Prisma), nunca las dos a la vez.
-- Precios en céntimos (S/ 129.00 = 12900). Sin pagos en línea y sin datos
-- personales de clientes: el contacto ocurre por WhatsApp.
-- ============================================================================

CREATE TYPE "TipoPrenda"     AS ENUM ('POLO', 'POLERA', 'ZIPPER', 'CASACA');
CREATE TYPE "EstadoProducto" AS ENUM ('BORRADOR', 'PUBLICADO', 'OCULTO');
CREATE TYPE "EstadoPedido"   AS ENUM ('PENDIENTE', 'ACEPTADO', 'RECHAZADO', 'PREPARANDO', 'ENVIADO', 'ENTREGADO', 'CANCELADO');
CREATE TYPE "MotivoStock"    AS ENUM ('RESERVA', 'LIBERACION', 'VENTA', 'AJUSTE', 'DEVOLUCION');

CREATE TABLE "Categoria" (
  "id"     TEXT NOT NULL,
  "slug"   TEXT NOT NULL,
  "nombre" TEXT NOT NULL,
  CONSTRAINT "Categoria_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Categoria_slug_key" ON "Categoria"("slug");

CREATE TABLE "Producto" (
  "id"                  TEXT NOT NULL,
  "slug"                TEXT NOT NULL,
  "skuBase"             TEXT NOT NULL,
  "nombre"              TEXT NOT NULL,
  "descripcion"         TEXT NOT NULL,
  "tipo"                "TipoPrenda" NOT NULL,
  "estado"              "EstadoProducto" NOT NULL DEFAULT 'BORRADOR',
  "destacado"           BOOLEAN NOT NULL DEFAULT false,
  "nuevo"               BOOLEAN NOT NULL DEFAULT false,
  "proximamente"        BOOLEAN NOT NULL DEFAULT false,
  "precioCentimos"      INTEGER,
  "precioPromoCentimos" INTEGER,
  "imagenes"            TEXT[] NOT NULL DEFAULT '{}',
  "categoriaId"         TEXT NOT NULL,
  "creadoEn"            TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "actualizadoEn"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Producto_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "Producto_categoriaId_fkey" FOREIGN KEY ("categoriaId") REFERENCES "Categoria"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "producto_precio_positivo" CHECK ("precioCentimos" IS NULL OR "precioCentimos" > 0),
  CONSTRAINT "producto_promo_valida" CHECK ("precioPromoCentimos" IS NULL OR ("precioCentimos" IS NOT NULL AND "precioPromoCentimos" > 0 AND "precioPromoCentimos" < "precioCentimos")),
  CONSTRAINT "producto_precio_si_vendible" CHECK ("proximamente" OR "estado" <> 'PUBLICADO' OR "precioCentimos" IS NOT NULL)
);
CREATE UNIQUE INDEX "Producto_slug_key" ON "Producto"("slug");
CREATE UNIQUE INDEX "Producto_skuBase_key" ON "Producto"("skuBase");

-- Una variante = una talla en un color, con su propio stock.
-- disponible = stock - reservado.
CREATE TABLE "Variante" (
  "id"         TEXT NOT NULL,
  "productoId" TEXT NOT NULL,
  "talla"      TEXT NOT NULL,
  "color"      TEXT NOT NULL,
  "colorHex"   TEXT NOT NULL,
  "sku"        TEXT NOT NULL,
  "stock"      INTEGER NOT NULL DEFAULT 0,
  "reservado"  INTEGER NOT NULL DEFAULT 0,
  "activo"     BOOLEAN NOT NULL DEFAULT true,
  CONSTRAINT "Variante_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "Variante_productoId_fkey" FOREIGN KEY ("productoId") REFERENCES "Producto"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "variante_stock_no_negativo" CHECK ("stock" >= 0),
  CONSTRAINT "variante_reservado_valido" CHECK ("reservado" >= 0 AND "reservado" <= "stock")
);
CREATE UNIQUE INDEX "Variante_sku_key" ON "Variante"("sku");
CREATE UNIQUE INDEX "Variante_productoId_talla_color_key" ON "Variante"("productoId", "talla", "color");

-- Solicitud de pedido: nace PENDIENTE y reserva stock por tiempo limitado.
-- El stock se descuenta definitivamente cuando el administrador ACEPTA.
CREATE TABLE "Pedido" (
  "id"                TEXT NOT NULL,
  "numero"            SERIAL NOT NULL,
  "estado"            "EstadoPedido" NOT NULL DEFAULT 'PENDIENTE',
  "claveIdempotencia" TEXT NOT NULL,
  "subtotalCentimos"  INTEGER NOT NULL,
  "moneda"            TEXT NOT NULL DEFAULT 'PEN',
  "reservaVenceEn"    TIMESTAMP(3),
  "cerradoPor"        TEXT,
  "notaAdmin"         TEXT,
  "creadoEn"          TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "actualizadoEn"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Pedido_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "pedido_subtotal_no_negativo" CHECK ("subtotalCentimos" >= 0)
);
CREATE UNIQUE INDEX "Pedido_numero_key" ON "Pedido"("numero");
CREATE UNIQUE INDEX "Pedido_claveIdempotencia_key" ON "Pedido"("claveIdempotencia");
CREATE INDEX "Pedido_estado_reservaVenceEn_idx" ON "Pedido"("estado", "reservaVenceEn");

CREATE TABLE "PedidoItem" (
  "id"                 TEXT NOT NULL,
  "pedidoId"           TEXT NOT NULL,
  "varianteId"         TEXT NOT NULL,
  "nombre"             TEXT NOT NULL,
  "talla"              TEXT NOT NULL,
  "color"              TEXT NOT NULL,
  "precioUnitCentimos" INTEGER NOT NULL,
  "cantidad"           INTEGER NOT NULL,
  CONSTRAINT "PedidoItem_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "PedidoItem_pedidoId_fkey" FOREIGN KEY ("pedidoId") REFERENCES "Pedido"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "PedidoItem_varianteId_fkey" FOREIGN KEY ("varianteId") REFERENCES "Variante"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "item_cantidad_positiva" CHECK ("cantidad" > 0),
  CONSTRAINT "item_precio_no_negativo" CHECK ("precioUnitCentimos" >= 0)
);

-- Historial de cambios de stock, para poder auditarlo.
CREATE TABLE "MovimientoStock" (
  "id"         TEXT NOT NULL,
  "varianteId" TEXT NOT NULL,
  "pedidoId"   TEXT,
  "adminId"    TEXT,
  "delta"      INTEGER NOT NULL,
  "motivo"     "MotivoStock" NOT NULL,
  "creadoEn"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MovimientoStock_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "MovimientoStock_varianteId_fkey" FOREIGN KEY ("varianteId") REFERENCES "Variante"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "MovimientoStock_pedidoId_fkey" FOREIGN KEY ("pedidoId") REFERENCES "Pedido"("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- Personas autorizadas a usar el panel (el id es el del usuario en el sistema de autenticación).
CREATE TABLE "Administrador" (
  "id"       TEXT NOT NULL,
  "email"    TEXT NOT NULL,
  "activo"   BOOLEAN NOT NULL DEFAULT true,
  "creadoEn" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Administrador_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Administrador_email_key" ON "Administrador"("email");

-- Registro de operaciones administrativas relevantes.
CREATE TABLE "RegistroAdmin" (
  "id"        TEXT NOT NULL,
  "adminId"   TEXT NOT NULL,
  "accion"    TEXT NOT NULL,
  "entidad"   TEXT NOT NULL,
  "entidadId" TEXT,
  "detalle"   TEXT,
  "creadoEn"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "RegistroAdmin_pkey" PRIMARY KEY ("id")
);

-- ----------------------------------------------------------------------------
-- SEGURIDAD: Supabase publica las tablas por una API abierta con la llave
-- "anon". Activar RLS sin políticas bloquea todo acceso por esa vía. La tienda
-- accede desde el servidor con la cadena de conexión directa. NO crees
-- políticas públicas sobre Pedido, Administrador ni RegistroAdmin.
-- ----------------------------------------------------------------------------
ALTER TABLE "Categoria"       ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Producto"        ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Variante"        ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Pedido"          ENABLE ROW LEVEL SECURITY;
ALTER TABLE "PedidoItem"      ENABLE ROW LEVEL SECURITY;
ALTER TABLE "MovimientoStock" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Administrador"   ENABLE ROW LEVEL SECURITY;
ALTER TABLE "RegistroAdmin"   ENABLE ROW LEVEL SECURITY;
