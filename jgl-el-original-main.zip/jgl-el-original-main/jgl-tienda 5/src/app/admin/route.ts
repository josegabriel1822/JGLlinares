import { readFile } from "node:fs/promises";
import path from "node:path";

export const dynamic = "force-static";

// Pantalla del panel. El HTML en sí no es secreto: TODA la protección está en la API (/api/admin/*),
// que verifica sesión y permisos en el servidor en cada operación.
export async function GET() {
  const html = await readFile(path.join(process.cwd(), "storefront", "admin.html"), "utf8");
  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8", "X-Robots-Tag": "noindex, nofollow", "Cache-Control": "no-store" } });
}
