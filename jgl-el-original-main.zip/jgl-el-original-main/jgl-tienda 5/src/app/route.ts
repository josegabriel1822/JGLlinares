import { readFile } from "node:fs/promises";
import path from "node:path";

export const dynamic = "force-static";

// Sirve la tienda (storefront/jgl.html) en la dirección principal "/".
export async function GET() {
  const html = await readFile(path.join(process.cwd(), "storefront", "jgl.html"), "utf8");
  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
