import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { aProductoPublico } from "@/lib/dto";

export const dynamic = "force-dynamic";

// Catálogo público (solo lectura): únicamente productos PUBLICADOS. Sin datos internos ni de clientes.
export async function GET() {
  try {
    const filas = await db.producto.findMany({
      where: { estado: "PUBLICADO" },
      include: { categoria: true, variantes: true },
      orderBy: { creadoEn: "asc" },
    });
    return NextResponse.json(
      { modoDemo: process.env.TIENDA_MODO_DEMO !== "false", productos: filas.map(aProductoPublico) },
      { headers: { "Cache-Control": "no-store" } }, // el stock cambia: nunca se muestra información vieja
    );
  } catch {
    // No se filtra el detalle del error al público.
    return NextResponse.json({ error: "No se pudo cargar el catálogo." }, { status: 503 });
  }
}
