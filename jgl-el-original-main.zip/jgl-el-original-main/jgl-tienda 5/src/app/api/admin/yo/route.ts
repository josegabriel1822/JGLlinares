import { conAdmin } from "@/lib/admin";
export const dynamic = "force-dynamic";
export const GET = conAdmin(async ({ admin }) => ({ datos: { email: admin.email } }));
