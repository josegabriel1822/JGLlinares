import { conAdmin } from "@/lib/admin";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export const GET = conAdmin(async () => {
  const filas = await db.movimientoStock.findMany({ include: { variante: { select: { sku: true } }, pedido: { select: { numero: true } } }, orderBy: { creadoEn: "desc" }, take: 200 });
  return { datos: { movimientos: filas.map((m) => ({ creadoEn: m.creadoEn, sku: m.variante.sku, motivo: m.motivo, delta: m.delta, pedido: m.pedido?.numero ?? null, admin: m.adminId ? "administrador" : "cliente/sistema" })) } };
});
