import { configAuth, esAdministrador, responder } from "@/lib/admin";
import { cookiesDeTokens, iniciarSesion } from "@/lib/admin-auth";
import { db } from "@/lib/db";
import { hashIp, obtenerIp, origenValido } from "@/lib/seguridad";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!origenValido(req.headers.get("origin"), req.headers.get("host"))) return responder({ error: "No permitido." }, 403);
  const cfg = configAuth(), sal = process.env.HASH_SALT;
  if (!cfg || !sal || sal.length < 16) return responder({ error: "El panel no está configurado." }, 503);
  try {
    const t = await req.text();
    if (t.length > 2000) return responder({ error: "Solicitud inválida." }, 400);
    const { email, password } = JSON.parse(t) as { email?: unknown; password?: unknown };
    if (typeof email !== "string" || typeof password !== "string" || email.length > 200 || password.length > 200 || !email || !password) return responder({ error: "Solicitud inválida." }, 400);

    // Freno a los intentos de adivinar contraseñas: 10 cada 15 minutos por visitante
    const huella = hashIp(obtenerIp(req.headers), sal, "login");
    const lim = await db.$queryRaw<{ ok: boolean }[]>`SELECT jgl_limitar(${huella}, ${10}, ${900}) AS ok`;
    if (!lim[0]?.ok) return responder({ error: "Demasiados intentos. Espera unos minutos." }, 429);

    const s = await iniciarSesion(cfg, email.trim(), password);
    // Mismo mensaje si la clave es incorrecta o si la persona no es administradora (no se revela cuál)
    if (!s || !(await esAdministrador(s.usuario.id))) return responder({ error: "No pudimos iniciar sesión." }, 401);
    await db.registroAdmin.create({ data: { adminId: s.usuario.id, accion: "LOGIN", entidad: "Sesion" } });
    return responder({ ok: true, email: s.usuario.email }, 200, cookiesDeTokens(s.tokens));
  } catch (e) {
    console.error("Error de inicio de sesión", e instanceof Error ? e.message : e);
    return responder({ error: "No pudimos iniciar sesión." }, 401);
  }
}
