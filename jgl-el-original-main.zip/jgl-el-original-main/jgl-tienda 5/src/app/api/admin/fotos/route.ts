import { conAdmin, configStorage } from "@/lib/admin";
import { db } from "@/lib/db";
import { MAX_BYTES_FOTO, detectarImagen, nombreArchivo } from "@/lib/imagen";
import { randomBytes } from "node:crypto";

export const dynamic = "force-dynamic";

// Sube una foto (bytes en bruto). Solo administradores. Se valida el contenido real, el tipo y el tamaño.
export const POST = conAdmin(async ({ req, admin }) => {
  const cfg = configStorage();
  if (!cfg) return { datos: { error: "El almacenamiento de fotos no está configurado." }, status: 503 };
  if (Number(req.headers.get("content-length") || 0) > MAX_BYTES_FOTO) return { datos: { error: "La foto supera los 5 MB." }, status: 413 };
  const bytes = new Uint8Array(await req.arrayBuffer());
  if (bytes.length > MAX_BYTES_FOTO) return { datos: { error: "La foto supera los 5 MB." }, status: 413 };
  const tipo = detectarImagen(bytes);
  if (!tipo) return { datos: { error: "Solo se aceptan fotos JPG, PNG o WEBP." }, status: 415 };
  const ruta = `fotos/${nombreArchivo(tipo, randomBytes(16).toString("hex"))}`;
  const r = await fetch(`${cfg.url}/storage/v1/object/${cfg.bucket}/${ruta}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${cfg.clave}`, apikey: cfg.clave, "Content-Type": tipo, "x-upsert": "false", "Cache-Control": "max-age=3600" },
    body: bytes,
  });
  if (!r.ok) { console.error("Fallo al subir foto", r.status); return { datos: { error: "No se pudo guardar la foto." }, status: 502 }; }
  await db.registroAdmin.create({ data: { adminId: admin.id, accion: "SUBIR_FOTO", entidad: "Foto", detalle: ruta } });
  return { datos: { url: `${cfg.url}/storage/v1/object/public/${cfg.bucket}/${ruta}` }, status: 201 };
});
