import { conAdmin, leerJson, prefijoFotos } from "@/lib/admin";
import { db } from "@/lib/db";
import { validarProducto } from "@/lib/producto-admin";
import { ErrorNegocio, guardarProducto } from "@/lib/productos-db";

export const dynamic = "force-dynamic";

export const PUT = conAdmin<{ id: string }>(async ({ req, admin, params }) => {
  if (!/^[A-Za-z0-9_-]{5,60}$/.test(params.id)) return { datos: { errores: ["Solicitud inválida."] }, status: 400 };
  let cuerpo: unknown;
  try { cuerpo = await leerJson(req); } catch { return { datos: { errores: ["Solicitud inválida."] }, status: 400 }; }
  const cats = (await db.categoria.findMany({ select: { slug: true } })).map((c) => c.slug);
  const v = validarProducto(cuerpo, prefijoFotos(), cats);
  if (!v.ok) return { datos: { errores: v.errores }, status: 400 };
  try {
    return { datos: { ok: true, id: await guardarProducto(v.datos, admin.id, params.id) } };
  } catch (e) {
    if (e instanceof ErrorNegocio) return { datos: { errores: [e.message] }, status: 409 };
    const code = (e as { code?: string }).code;
    if (code === "P2002") return { datos: { errores: ["Ya existe un producto o variante con ese nombre, SKU o combinación de talla y color."] }, status: 409 };
    if (code === "P2025") return { datos: { errores: ["El producto no existe."] }, status: 404 };
    throw e;
  }
});
