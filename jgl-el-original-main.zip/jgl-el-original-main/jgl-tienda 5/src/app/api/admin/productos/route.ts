import { conAdmin, leerJson, prefijoFotos } from "@/lib/admin";
import { db } from "@/lib/db";
import { validarProducto } from "@/lib/producto-admin";
import { ErrorNegocio, guardarProducto } from "@/lib/productos-db";

export const dynamic = "force-dynamic";

export const GET = conAdmin(async () => {
  const filas = await db.producto.findMany({ include: { categoria: true, variantes: true }, orderBy: { creadoEn: "asc" } });
  return { datos: { productos: filas.map((p) => ({
    id: p.id, slug: p.slug, skuBase: p.skuBase, nombre: p.nombre, descripcion: p.descripcion, tipo: p.tipo, estado: p.estado, categoria: p.categoria.slug,
    destacado: p.destacado, nuevo: p.nuevo, proximamente: p.proximamente,
    precio: p.precioCentimos == null ? null : p.precioCentimos / 100, precioPromo: p.precioPromoCentimos == null ? null : p.precioPromoCentimos / 100,
    imagenes: p.imagenes,
    variantes: p.variantes.map((v) => ({ sku: v.sku, talla: v.talla, color: v.color, colorHex: v.colorHex, stock: v.stock, reservado: v.reservado, activo: v.activo })),
  })) } };
});

export const POST = conAdmin(async ({ req, admin }) => {
  let cuerpo: unknown;
  try { cuerpo = await leerJson(req); } catch { return { datos: { errores: ["Solicitud inválida."] }, status: 400 }; }
  const cats = (await db.categoria.findMany({ select: { slug: true } })).map((c) => c.slug);
  const v = validarProducto(cuerpo, prefijoFotos(), cats);
  if (!v.ok) return { datos: { errores: v.errores }, status: 400 };
  try {
    return { datos: { ok: true, id: await guardarProducto(v.datos, admin.id) }, status: 201 };
  } catch (e) {
    if (e instanceof ErrorNegocio) return { datos: { errores: [e.message] }, status: 409 };
    if ((e as { code?: string }).code === "P2002") return { datos: { errores: ["Ya existe un producto o variante con ese nombre, SKU o combinación de talla y color."] }, status: 409 };
    throw e;
  }
});
