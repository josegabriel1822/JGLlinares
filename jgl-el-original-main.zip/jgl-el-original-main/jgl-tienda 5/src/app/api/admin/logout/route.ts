import { configAuth, responder } from "@/lib/admin";
import { COOKIE_ACCESO, COOKIE_REFRESCO, cerrarSesion, cookieBorrar, leerCookies } from "@/lib/admin-auth";
import { origenValido } from "@/lib/seguridad";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!origenValido(req.headers.get("origin"), req.headers.get("host"))) return responder({ error: "No permitido." }, 403);
  const cfg = configAuth(), at = leerCookies(req.headers.get("cookie"))[COOKIE_ACCESO];
  if (cfg && at) await cerrarSesion(cfg, at);
  return responder({ ok: true }, 200, [cookieBorrar(COOKIE_ACCESO), cookieBorrar(COOKIE_REFRESCO)]);
}
