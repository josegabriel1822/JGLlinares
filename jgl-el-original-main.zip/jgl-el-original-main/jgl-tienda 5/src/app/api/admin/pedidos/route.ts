import { conAdmin } from "@/lib/admin";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";
const ESTADOS = ["PENDIENTE", "ACEPTADO", "RECHAZADO", "PREPARANDO", "ENVIADO", "ENTREGADO", "CANCELADO"] as const;

export const GET = conAdmin(async ({ req }) => {
  const e = new URL(req.url).searchParams.get("estado");
  const estado = ESTADOS.find((x) => x === e);
  const filas = await db.pedido.findMany({ where: estado ? { estado } : {}, include: { items: true }, orderBy: { creadoEn: "desc" }, take: 100 });
  return { datos: { pedidos: filas.map((p) => ({
    id: p.id, numero: p.numero, estado: p.estado, subtotalCentimos: p.subtotalCentimos, creadoEn: p.creadoEn, reservaVenceEn: p.reservaVenceEn,
    cerradoPor: p.cerradoPor, notaAdmin: p.notaAdmin,
    items: p.items.map((i) => ({ nombre: i.nombre, talla: i.talla, color: i.color, cantidad: i.cantidad, precioUnitCentimos: i.precioUnitCentimos })),
  })) } };
});
