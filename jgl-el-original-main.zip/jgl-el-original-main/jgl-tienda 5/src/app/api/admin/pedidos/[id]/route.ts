import { conAdmin, leerJson } from "@/lib/admin";
import { db } from "@/lib/db";
import { validarAccion } from "@/lib/producto-admin";

export const dynamic = "force-dynamic";
type R = { r: { ok: boolean; error?: string; estado?: string } };
const MENSAJES: Record<string, string> = {
  estado_invalido: "El pedido ya no está en un estado que permita esa acción. Actualiza la lista.",
  no_existe: "El pedido no existe.",
  inconsistencia_stock: "El stock reservado no coincide. Revisa el inventario.",
};

// Aceptar, rechazar, cancelar o avanzar un pedido. El stock lo mueven las funciones de la base de datos.
export const POST = conAdmin<{ id: string }>(async ({ req, admin, params }) => {
  let cuerpo: unknown;
  try { cuerpo = await leerJson(req, 2000); } catch { return { datos: { error: "Solicitud inválida." }, status: 400 }; }
  const a = validarAccion(cuerpo);
  if (!a.ok || !/^[A-Za-z0-9-]{10,60}$/.test(params.id)) return { datos: { error: "Solicitud inválida." }, status: 400 };
  const id = params.id, ad = admin.id, nota = a.nota;
  let f: R[];
  switch (a.accion) {
    case "aceptar": f = await db.$queryRaw<R[]>`SELECT jgl_aceptar_pedido(${id}, ${ad}) AS r`; break;
    case "rechazar": f = await db.$queryRaw<R[]>`SELECT jgl_rechazar_pedido(${id}, ${ad}, ${nota}) AS r`; break;
    case "cancelar": f = await db.$queryRaw<R[]>`SELECT jgl_cancelar_pedido(${id}, ${ad}, ${nota}) AS r`; break;
    case "preparando": f = await db.$queryRaw<R[]>`SELECT jgl_cambiar_estado_pedido(${id}, ${"PREPARANDO"}, ${ad}) AS r`; break;
    case "enviado": f = await db.$queryRaw<R[]>`SELECT jgl_cambiar_estado_pedido(${id}, ${"ENVIADO"}, ${ad}) AS r`; break;
    default: f = await db.$queryRaw<R[]>`SELECT jgl_cambiar_estado_pedido(${id}, ${"ENTREGADO"}, ${ad}) AS r`;
  }
  const r = f[0]?.r;
  if (r?.ok) return { datos: { ok: true, estado: r.estado } };
  return { datos: { ok: false, error: MENSAJES[r?.error ?? ""] ?? "No se pudo completar la acción." }, status: 409 };
});
