import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { validarSolicitud } from "@/lib/pedido";
import { hashIp, obtenerIp, origenValido } from "@/lib/seguridad";

export const dynamic = "force-dynamic";

type Respuesta = {
  ok: boolean;
  error?: string;
  numero?: number;
  subtotalCentimos?: number;
  items?: unknown[];
  errores?: unknown[];
};

const horasReserva = Math.min(Math.max(Number(process.env.RESERVA_HORAS) || 24, 1), 168);
const maxPorHora = Math.min(Math.max(Number(process.env.LIMITE_PEDIDOS_POR_HORA) || 10, 1), 1000);

// Registra una solicitud de pedido PENDIENTE y reserva el stock. NO cobra ni marca nada como pagado.
export async function POST(req: Request) {
  // 1) Solo desde nuestra propia página
  if (!origenValido(req.headers.get("origin"), req.headers.get("host"))) {
    return NextResponse.json({ ok: false, error: "Solicitud no permitida." }, { status: 403 });
  }

  // 2) Tamaño y formato
  const texto = await req.text();
  if (texto.length > 5000) return NextResponse.json({ ok: false, error: "Solicitud demasiado grande." }, { status: 413 });
  let cuerpo: unknown;
  try {
    cuerpo = JSON.parse(texto);
  } catch {
    return NextResponse.json({ ok: false, error: "Solicitud inválida." }, { status: 400 });
  }
  const v = validarSolicitud(cuerpo);
  if (!v.ok) return NextResponse.json({ ok: false, error: "Solicitud inválida." }, { status: 400 });

  try {
    // 3) Límite de solicitudes por visitante (se guarda un hash de la IP, no la IP)
    const sal = process.env.HASH_SALT;
    if (!sal || sal.length < 16) {
      console.error("Falta HASH_SALT (mínimo 16 caracteres).");
      return NextResponse.json({ ok: false, error: "La tienda no está configurada todavía." }, { status: 503 });
    }
    const huella = hashIp(obtenerIp(req.headers), sal, "pedidos");
    const lim = await db.$queryRaw<{ permitido: boolean }[]>`SELECT jgl_limitar(${huella}, ${maxPorHora}, ${3600}) AS permitido`;
    if (!lim[0]?.permitido) {
      return NextResponse.json({ ok: false, error: "Demasiados intentos. Inténtalo más tarde." }, { status: 429 });
    }

    // 4) La base de datos valida precios, variantes y stock, y reserva de forma atómica
    const filas = await db.$queryRaw<{ r: Respuesta }[]>`
      SELECT jgl_crear_solicitud(${JSON.stringify(v.items)}::jsonb, ${v.clave}, ${horasReserva}) AS r`;
    const r = filas[0]?.r;
    if (!r) throw new Error("sin respuesta");

    if (r.ok) {
      // El navegador solo recibe lo necesario para armar el mensaje de WhatsApp.
      return NextResponse.json({ ok: true, numero: r.numero, items: r.items, subtotalCentimos: r.subtotalCentimos }, { headers: { "Cache-Control": "no-store" } });
    }
    if (r.error === "sin_stock") {
      return NextResponse.json({ ok: false, error: "Algunas prendas cambiaron de disponibilidad. Revisa tu carrito.", errores: r.errores }, { status: 409 });
    }
    return NextResponse.json({ ok: false, error: "No pudimos registrar la solicitud. Revisa tu carrito." }, { status: 400 });
  } catch (e) {
    console.error("Error al crear la solicitud", e instanceof Error ? e.message : e);
    return NextResponse.json({ ok: false, error: "No pudimos registrar la solicitud. Inténtalo de nuevo en unos minutos." }, { status: 503 });
  }
}
