// Protección del panel: CADA operación administrativa pasa por aquí. Nada se decide en el navegador.
import { NextResponse } from "next/server";
import { db } from "./db";
import { COOKIE_ACCESO, COOKIE_REFRESCO, cookiesDeTokens, leerCookies, refrescarSesion, usuarioDeToken, type Cfg } from "./admin-auth";
import { origenValido } from "./seguridad";

export type AdminSesion = { id: string; email: string };

export function configAuth(): Cfg | null {
  const url = process.env.SUPABASE_URL, anon = process.env.SUPABASE_ANON_KEY;
  return url && anon ? { url: url.replace(/\/+$/, ""), anon } : null;
}
export function configStorage() {
  const url = process.env.SUPABASE_URL, clave = process.env.SUPABASE_SERVICE_ROLE_KEY, bucket = process.env.BUCKET_FOTOS || "productos";
  return url && clave ? { url: url.replace(/\/+$/, ""), clave, bucket } : null;
}
export const prefijoFotos = () => {
  const c = configStorage();
  return c ? `${c.url}/storage/v1/object/public/${c.bucket}/` : "https://invalido.local/";
};

export function responder(datos: unknown, status = 200, cookies: string[] = []) {
  const res = NextResponse.json(datos, { status, headers: { "Cache-Control": "no-store" } });
  for (const c of cookies) res.headers.append("Set-Cookie", c);
  return res;
}

export async function esAdministrador(id: string): Promise<boolean> {
  return !!(await db.administrador.findFirst({ where: { id, activo: true }, select: { id: true } }));
}

export async function exigirAdmin(req: Request): Promise<{ ok: true; admin: AdminSesion; cookies: string[] } | { ok: false; res: Response }> {
  if (req.method !== "GET" && !origenValido(req.headers.get("origin"), req.headers.get("host"))) return { ok: false, res: responder({ error: "No permitido." }, 403) };
  const cfg = configAuth();
  if (!cfg) return { ok: false, res: responder({ error: "El panel no está configurado." }, 503) };
  const c = leerCookies(req.headers.get("cookie"));
  let cookies: string[] = [];
  let usuario = c[COOKIE_ACCESO] ? await usuarioDeToken(cfg, c[COOKIE_ACCESO]) : null;
  if (!usuario && c[COOKIE_REFRESCO]) {
    const s = await refrescarSesion(cfg, c[COOKIE_REFRESCO]);
    if (s) { usuario = s.usuario; cookies = cookiesDeTokens(s.tokens); }
  }
  if (!usuario) return { ok: false, res: responder({ error: "Inicia sesión." }, 401) };
  if (!(await esAdministrador(usuario.id))) return { ok: false, res: responder({ error: "No tienes permiso." }, 403) };
  return { ok: true, admin: { id: usuario.id, email: usuario.email }, cookies };
}

type Ctx<P> = { req: Request; admin: AdminSesion; params: P };
export function conAdmin<P = Record<string, never>>(fn: (c: Ctx<P>) => Promise<{ datos: unknown; status?: number }>) {
  return async (req: Request, ctx?: { params?: Promise<P> }) => {
    const g = await exigirAdmin(req);
    if (!g.ok) return g.res;
    try {
      const params = (ctx?.params ? await ctx.params : {}) as P;
      const r = await fn({ req, admin: g.admin, params });
      return responder(r.datos, r.status ?? 200, g.cookies);
    } catch (e) {
      console.error("Error en el panel", e instanceof Error ? e.message : e); // el detalle queda en el servidor
      return responder({ error: "No se pudo completar la operación." }, 500, g.cookies);
    }
  };
}

export async function leerJson(req: Request, maxBytes = 200_000): Promise<unknown> {
  const texto = await req.text();
  if (texto.length > maxBytes) throw new Error("demasiado grande");
  return JSON.parse(texto);
}
