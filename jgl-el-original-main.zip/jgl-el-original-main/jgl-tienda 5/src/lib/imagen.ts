// Validación de fotos subidas: se mira el CONTENIDO real del archivo (no el nombre ni lo que diga el navegador).
export const MAX_BYTES_FOTO = 5 * 1024 * 1024; // 5 MB
export type TipoImagen = "image/jpeg" | "image/png" | "image/webp";

export function detectarImagen(b: Uint8Array): TipoImagen | null {
  if (b.length < 12) return null;
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a) return "image/png";
  const txt = (i: number, n: number) => String.fromCharCode(...b.slice(i, i + n));
  if (txt(0, 4) === "RIFF" && txt(8, 4) === "WEBP") return "image/webp";
  return null;
}

const EXT: Record<TipoImagen, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };
export function nombreArchivo(tipo: TipoImagen, aleatorio: string): string {
  return `${aleatorio.replace(/[^a-f0-9]/gi, "").slice(0, 32)}.${EXT[tipo]}`;
}
