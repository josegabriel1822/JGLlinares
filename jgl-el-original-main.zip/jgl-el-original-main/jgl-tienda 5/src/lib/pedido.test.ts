import { test } from "node:test";
import assert from "node:assert/strict";
import { validarSolicitud } from "./pedido.ts";

const ok = { items: [{ sku: "POLO-PREMIUM-A-M-NEGRO", cantidad: 2 }], clave: "a1b2c3d4-e5f6" };

test("acepta una solicitud válida", () => {
  const r = validarSolicitud(ok);
  assert.equal(r.ok, true);
});

test("ignora cualquier precio o nombre que mande el navegador", () => {
  const r = validarSolicitud({ ...ok, items: [{ sku: "A-1", cantidad: 1, precio: 0.01, nombre: "x" }] });
  assert.equal(r.ok, true);
  if (r.ok) assert.deepEqual(r.items, [{ sku: "A-1", cantidad: 1 }]);
});

test("rechaza cuerpos y claves inválidos", () => {
  for (const c of [null, "texto", 5, [], {}, { ...ok, clave: "corta" }, { ...ok, clave: "x".repeat(101) }, { ...ok, clave: "con espacios aqui" }, { items: ok.items }]) {
    assert.equal(validarSolicitud(c).ok, false, JSON.stringify(c));
  }
});

test("rechaza cantidades inválidas", () => {
  for (const cantidad of [0, -1, 11, 1.5, "2", null, NaN, Infinity]) {
    assert.equal(validarSolicitud({ ...ok, items: [{ sku: "A-1", cantidad }] }).ok, false, String(cantidad));
  }
});

test("rechaza SKU inválidos (intentos de inyección)", () => {
  for (const sku of ["", "a b", "x'; DROP TABLE \"Variante\";--", "<script>", 5, null, "x".repeat(101)]) {
    assert.equal(validarSolicitud({ ...ok, items: [{ sku, cantidad: 1 }] }).ok, false, String(sku));
  }
});

test("rechaza listas vacías o demasiado largas", () => {
  assert.equal(validarSolicitud({ ...ok, items: [] }).ok, false);
  assert.equal(validarSolicitud({ ...ok, items: Array.from({ length: 21 }, (_, i) => ({ sku: "S" + i, cantidad: 1 })) }).ok, false);
  assert.equal(validarSolicitud({ ...ok, items: Array.from({ length: 20 }, (_, i) => ({ sku: "S" + i, cantidad: 1 })) }).ok, true);
});
