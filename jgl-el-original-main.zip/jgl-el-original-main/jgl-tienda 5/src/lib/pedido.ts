// Validación de la solicitud de pedido que llega desde el navegador.
// Función pura (sin base de datos). El navegador solo envía SKU, cantidad y una clave:
// el precio, el nombre y el stock SIEMPRE los decide la base de datos.

export type ItemSolicitud = { sku: string; cantidad: number };
export type SolicitudValida = { ok: true; items: ItemSolicitud[]; clave: string };
export type SolicitudInvalida = { ok: false; motivo: string };

const PATRON = /^[A-Za-z0-9._-]+$/;
export const MAX_LINEAS = 20;
export const MAX_CANTIDAD_POR_LINEA = 10;

export function validarSolicitud(cuerpo: unknown): SolicitudValida | SolicitudInvalida {
  if (typeof cuerpo !== "object" || cuerpo === null || Array.isArray(cuerpo)) return { ok: false, motivo: "cuerpo" };
  const { items, clave } = cuerpo as Record<string, unknown>;

  if (typeof clave !== "string" || clave.length < 8 || clave.length > 100 || !PATRON.test(clave)) return { ok: false, motivo: "clave" };
  if (!Array.isArray(items) || items.length < 1 || items.length > MAX_LINEAS) return { ok: false, motivo: "items" };

  const salida: ItemSolicitud[] = [];
  for (const it of items) {
    if (typeof it !== "object" || it === null || Array.isArray(it)) return { ok: false, motivo: "item" };
    const { sku, cantidad } = it as Record<string, unknown>;
    if (typeof sku !== "string" || sku.length < 1 || sku.length > 100 || !PATRON.test(sku)) return { ok: false, motivo: "sku" };
    if (typeof cantidad !== "number" || !Number.isInteger(cantidad) || cantidad < 1 || cantidad > MAX_CANTIDAD_POR_LINEA) return { ok: false, motivo: "cantidad" };
    salida.push({ sku, cantidad });
  }
  return { ok: true, items: salida, clave };
}
