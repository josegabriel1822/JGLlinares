import { test } from "node:test";
import assert from "node:assert/strict";
import { slugificar, validarAccion, validarProducto } from "./producto-admin.ts";

const PRE = "https://x.supabase.co/storage/v1/object/public/productos/";
const CATS = ["polos", "poleras", "zippers", "casacas"];
const base = () => ({
  nombre: "Polo Clásico Ñandú", descripcion: "d", tipo: "POLO", estado: "PUBLICADO", categoria: "polos", skuBase: "POLO-CLASICO",
  destacado: true, nuevo: false, proximamente: false, precio: 129.9, precioPromo: 99, imagenes: [PRE + "fotos/a.jpg"],
  variantes: [{ sku: "POLO-CLASICO-M-NEGRO", talla: "m", color: "Negro", colorHex: "#0A0A0A", stock: 5, activo: true }],
});

test("producto válido: precios a céntimos, talla en mayúscula, slug limpio", () => {
  const r = validarProducto(base(), PRE, CATS);
  assert.equal(r.ok, true);
  if (r.ok) {
    assert.equal(r.datos.precioCentimos, 12990);
    assert.equal(r.datos.precioPromoCentimos, 9900);
    assert.equal(r.datos.variantes[0].talla, "M");
    assert.equal(r.datos.variantes[0].colorHex, "#0a0a0a");
    assert.equal(r.datos.slug, "polo-clasico-nandu");
  }
});

test("rechaza precios inválidos y promociones mayores al precio", () => {
  for (const precio of [0, -5, 1e9, "12", NaN, 10.123]) assert.equal(validarProducto({ ...base(), precio, precioPromo: null }, PRE, CATS).ok, false, String(precio));
  assert.equal(validarProducto({ ...base(), precioPromo: 129.9 }, PRE, CATS).ok, false);
  assert.equal(validarProducto({ ...base(), precioPromo: 200 }, PRE, CATS).ok, false);
});

test("las fotos solo pueden ser las subidas a nuestro almacenamiento", () => {
  for (const u of ["https://malo.com/x.jpg", "javascript:alert(1)", PRE + 'a" onerror="x', PRE + "con espacio.jpg"]) {
    assert.equal(validarProducto({ ...base(), imagenes: [u] }, PRE, CATS).ok, false, u);
  }
  assert.equal(validarProducto({ ...base(), imagenes: Array(9).fill(PRE + "a.jpg") }, PRE, CATS).ok, false);
});

test("variantes: SKU y talla+color repetidos, stock negativo o decimal", () => {
  const v = (o: object) => ({ sku: "A-1-N", talla: "S", color: "Negro", colorHex: "#000000", stock: 1, activo: true, ...o });
  assert.equal(validarProducto({ ...base(), variantes: [v({}), v({ talla: "M" })] }, PRE, CATS).ok, false); // SKU repetido
  assert.equal(validarProducto({ ...base(), variantes: [v({}), v({ sku: "A-2-N" })] }, PRE, CATS).ok, false); // talla+color repetidos
  for (const stock of [-1, 1.5, "3", null, 1e9]) assert.equal(validarProducto({ ...base(), variantes: [v({ stock })] }, PRE, CATS).ok, false, String(stock));
  assert.equal(validarProducto({ ...base(), variantes: [v({ colorHex: "rojo" })] }, PRE, CATS).ok, false);
});

test("un producto publicado necesita precio y variante activa; próximamente no", () => {
  assert.equal(validarProducto({ ...base(), precio: null, precioPromo: null }, PRE, CATS).ok, false);
  assert.equal(validarProducto({ ...base(), variantes: [] }, PRE, CATS).ok, false);
  assert.equal(validarProducto({ ...base(), precio: null, precioPromo: null, variantes: [], proximamente: true }, PRE, CATS).ok, true);
  assert.equal(validarProducto({ ...base(), estado: "BORRADOR", precio: null, precioPromo: null, variantes: [] }, PRE, CATS).ok, true);
});

test("categoría, tipo y estado deben ser de las listas permitidas", () => {
  assert.equal(validarProducto({ ...base(), categoria: "otra" }, PRE, CATS).ok, false);
  assert.equal(validarProducto({ ...base(), tipo: "PANTALON" }, PRE, CATS).ok, false);
  assert.equal(validarProducto({ ...base(), estado: "ELIMINADO" }, PRE, CATS).ok, false);
  assert.equal(validarProducto(null, PRE, CATS).ok, false);
  assert.equal(validarProducto({ ...base(), skuBase: "con espacios" }, PRE, CATS).ok, false);
});

test("slugificar y acciones de pedido", () => {
  assert.equal(slugificar("  Camisa Ñu & Más!! "), "camisa-nu-mas");
  assert.equal(validarAccion({ accion: "aceptar" }).ok, true);
  assert.equal(validarAccion({ accion: "rechazar", nota: "sin stock" }).ok, true);
  for (const x of [null, {}, { accion: "borrar" }, { accion: "aceptar", nota: 5 }, { accion: "aceptar", nota: "x".repeat(501) }]) assert.equal(validarAccion(x).ok, false);
});
