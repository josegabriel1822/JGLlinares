import { test } from "node:test";
import assert from "node:assert/strict";
import { aProductoPublico } from "./dto.ts";
import type { FilaProducto } from "./dto.ts";

const base: FilaProducto = {
  slug: "polo-x", nombre: "Polo X", descripcion: "d", tipo: "POLO", destacado: true, nuevo: true, proximamente: false,
  precioCentimos: 13900, precioPromoCentimos: 11900, imagenes: [], categoria: { slug: "polos" },
  variantes: [
    { talla: "XL", color: "Negro", colorHex: "#000000", sku: "X-XL-N", stock: 2, reservado: 0, activo: true },
    { talla: "M", color: "Negro", colorHex: "#000000", sku: "X-M-N", stock: 5, reservado: 2, activo: true },
    { talla: "M", color: "Marfil", colorHex: "#e9e0cc", sku: "X-M-M", stock: 1, reservado: 1, activo: true },
    { talla: "S", color: "Negro", colorHex: "#000000", sku: "X-S-N", stock: 9, reservado: 0, activo: false },
  ],
};

test("convierte céntimos a soles y detecta el precio promocional", () => {
  const p = aProductoPublico(base);
  assert.equal(p.precio, 139);
  assert.equal(p.precioPromo, 119);
  assert.equal(p.id, "polo-x");
  assert.equal(p.tipo, "polo");
  assert.equal(p.nuevo, true);
});

test("stock independiente por talla y color (stock - reservado)", () => {
  const p = aProductoPublico(base);
  const get = (sku: string) => p.variantes.find((v) => v.sku === sku)?.stock;
  assert.equal(get("X-M-N"), 3);
  assert.equal(get("X-M-M"), 0);
  assert.equal(get("X-XL-N"), 2);
});

test("ordena por talla y oculta variantes inactivas", () => {
  const p = aProductoPublico(base);
  assert.deepEqual(p.variantes.map((v) => v.sku), ["X-M-M", "X-M-N", "X-XL-N"]);
});

test("nunca muestra stock negativo", () => {
  const p = aProductoPublico({ ...base, variantes: [{ talla: "S", color: "N", colorHex: "#000", sku: "A", stock: 1, reservado: 3, activo: true }] });
  assert.equal(p.variantes[0].stock, 0);
});

test("una promoción mayor o igual al precio regular se ignora", () => {
  assert.equal("precioPromo" in aProductoPublico({ ...base, precioPromoCentimos: 13900 }), false);
  assert.equal("precioPromo" in aProductoPublico({ ...base, precioPromoCentimos: 15000 }), false);
});

test("próximo lanzamiento: sin precio y sin variantes", () => {
  const p = aProductoPublico({ ...base, proximamente: true, precioCentimos: null, precioPromoCentimos: null, variantes: [] });
  assert.equal(p.precio, null);
  assert.equal(p.proximamente, true);
  assert.deepEqual(p.variantes, []);
});

test("no filtra campos internos", () => {
  const p = aProductoPublico(base) as Record<string, unknown>;
  for (const k of ["precioCentimos", "precioPromoCentimos", "reservado", "activo", "estado"]) assert.equal(k in p, false);
  for (const v of p.variantes as Record<string, unknown>[]) for (const k of ["reservado", "activo", "colorHex"]) assert.equal(k in v, false);
});
