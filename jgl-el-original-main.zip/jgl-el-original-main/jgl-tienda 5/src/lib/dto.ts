// Convierte filas de la base de datos al formato público que usa la tienda.
// Es una función pura (sin base de datos), por eso se puede probar sola.
// Nunca expone campos internos (reservas, ids de base de datos, notas).

export type FilaVariante = { talla: string; color: string; colorHex: string; sku: string; stock: number; reservado: number; activo: boolean };
export type FilaProducto = {
  slug: string;
  nombre: string;
  descripcion: string;
  tipo: string;
  destacado: boolean;
  nuevo: boolean;
  proximamente: boolean;
  precioCentimos: number | null;
  precioPromoCentimos: number | null;
  imagenes: string[];
  categoria: { slug: string };
  variantes: FilaVariante[];
};

const ORDEN_TALLAS = ["XXS", "XS", "S", "M", "L", "XL", "XXL", "XXXL"];
const posicion = (t: string) => {
  const i = ORDEN_TALLAS.indexOf(t.toUpperCase());
  return i === -1 ? 99 : i;
};

export const enSoles = (centimos: number) => centimos / 100;

export function aProductoPublico(f: FilaProducto) {
  const variantes = f.variantes
    .filter((v) => v.activo)
    .map((v) => ({
      sku: v.sku,
      talla: v.talla,
      color: v.color,
      hex: v.colorHex,
      // Unidades disponibles = stock - reservado. Nunca negativo.
      stock: Math.max(0, v.stock - v.reservado),
    }))
    .sort((a, b) => posicion(a.talla) - posicion(b.talla) || a.talla.localeCompare(b.talla) || a.color.localeCompare(b.color));

  const promoValida =
    f.precioCentimos != null && f.precioPromoCentimos != null && f.precioPromoCentimos > 0 && f.precioPromoCentimos < f.precioCentimos;

  return {
    id: f.slug,
    nombre: f.nombre,
    categoria: f.categoria.slug,
    tipo: f.tipo.toLowerCase(),
    precio: f.precioCentimos == null ? null : enSoles(f.precioCentimos),
    ...(promoValida ? { precioPromo: enSoles(f.precioPromoCentimos as number) } : {}),
    ...(f.destacado ? { destacado: true } : {}),
    ...(f.nuevo ? { nuevo: true } : {}),
    ...(f.proximamente ? { proximamente: true } : {}),
    descripcion: f.descripcion,
    imagenes: f.imagenes,
    variantes,
  };
}
