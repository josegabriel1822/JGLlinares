// Utilidades de seguridad (puras, para poder probarlas sin servidor).
import { createHash } from "node:crypto";

// Acepta la petición solo si viene de la misma página web (protege contra envíos desde otros sitios).
export function origenValido(origin: string | null, host: string | null): boolean {
  if (!origin) return true; // llamadas sin cabecera Origin (no vienen de un navegador de otro sitio)
  if (!host) return false;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

// IP del visitante según las cabeceras que pone el hosting.
export function obtenerIp(cabeceras: { get(nombre: string): string | null }): string {
  const real = cabeceras.get("x-real-ip");
  if (real) return real.trim();
  const reenviada = cabeceras.get("x-forwarded-for");
  if (reenviada) return reenviada.split(",")[0].trim();
  return "desconocida";
}

// Se guarda un HASH de la IP (con una sal secreta del servidor), nunca la IP en claro.
export function hashIp(ip: string, sal: string, ambito: string): string {
  return createHash("sha256").update(`${sal}|${ambito}|${ip}`).digest("hex");
}
