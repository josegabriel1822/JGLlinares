import { test } from "node:test";
import assert from "node:assert/strict";
import { detectarImagen, nombreArchivo } from "./imagen.ts";

const rel = (...b: number[]) => Uint8Array.from([...b, ...new Array(20).fill(0)]);
const ascii = (s: string) => [...s].map((c) => c.charCodeAt(0));

test("reconoce JPEG, PNG y WEBP por su contenido", () => {
  assert.equal(detectarImagen(rel(0xff, 0xd8, 0xff, 0xe0)), "image/jpeg");
  assert.equal(detectarImagen(rel(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)), "image/png");
  assert.equal(detectarImagen(Uint8Array.from([...ascii("RIFF"), 1, 2, 3, 4, ...ascii("WEBP"), 0, 0])), "image/webp");
});

test("rechaza archivos que no son imágenes aunque se llamen .jpg", () => {
  assert.equal(detectarImagen(Uint8Array.from(ascii("<?php echo 1; ?> ........."))), null);
  assert.equal(detectarImagen(Uint8Array.from(ascii("<svg onload=alert(1)> ......"))), null);
  assert.equal(detectarImagen(Uint8Array.from(ascii("%PDF-1.7 .............."))), null);
  assert.equal(detectarImagen(new Uint8Array(3)), null);
});

test("el nombre del archivo es seguro", () => {
  assert.match(nombreArchivo("image/png", "../../etc/passwd"), /^[a-f0-9]+\.png$/);
  assert.match(nombreArchivo("image/jpeg", "abc123def456"), /^[a-f0-9]+\.jpg$/);
  assert.equal(nombreArchivo("image/webp", "../x").includes("/"), false);
});
