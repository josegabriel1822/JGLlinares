import { db } from "./db";
import type { ProductoValido } from "./producto-admin";

export class ErrorNegocio extends Error {}

// Crea o edita un producto y sus variantes en UNA transacción: si algo falla, no se guarda nada.
// El stock se cambia con jgl_ajustar_stock para que quede en el historial y respete las reservas.
export async function guardarProducto(d: ProductoValido, adminId: string, id?: string): Promise<string> {
  return db.$transaction(async (tx) => {
    const cat = await tx.categoria.findUnique({ where: { slug: d.categoria } });
    if (!cat) throw new ErrorNegocio("La categoría no existe.");
    const datos = {
      slug: d.slug, skuBase: d.skuBase, nombre: d.nombre, descripcion: d.descripcion, tipo: d.tipo, estado: d.estado,
      destacado: d.destacado, nuevo: d.nuevo, proximamente: d.proximamente, precioCentimos: d.precioCentimos,
      precioPromoCentimos: d.precioPromoCentimos, imagenes: d.imagenes, categoriaId: cat.id,
    };
    const prod = id ? await tx.producto.update({ where: { id }, data: datos }) : await tx.producto.create({ data: datos });
    for (const v of d.variantes) {
      const ex = await tx.variante.findUnique({ where: { sku: v.sku } });
      if (ex && ex.productoId !== prod.id) throw new ErrorNegocio(`El SKU ${v.sku} ya pertenece a otro producto.`);
      if (ex) await tx.variante.update({ where: { sku: v.sku }, data: { talla: v.talla, color: v.color, colorHex: v.colorHex, activo: v.activo } });
      else await tx.variante.create({ data: { productoId: prod.id, talla: v.talla, color: v.color, colorHex: v.colorHex, sku: v.sku, stock: 0, activo: v.activo } });
      if (v.stock !== (ex ? ex.stock : 0)) {
        const r = await tx.$queryRaw<{ r: { ok: boolean; error?: string } }[]>`SELECT jgl_ajustar_stock(${v.sku}, ${v.stock}, ${adminId}) AS r`;
        if (!r[0]?.r?.ok) {
          throw new ErrorNegocio(r[0]?.r?.error === "menor_que_reservado"
            ? `${v.sku}: el stock no puede ser menor que las unidades reservadas por pedidos pendientes.`
            : `No se pudo ajustar el stock de ${v.sku}.`);
        }
      }
    }
    await tx.registroAdmin.create({ data: { adminId, accion: id ? "EDITAR_PRODUCTO" : "CREAR_PRODUCTO", entidad: "Producto", entidadId: prod.id, detalle: prod.slug } });
    return prod.id;
  });
}
