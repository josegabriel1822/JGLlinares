// Inicio de sesión de administradores con Supabase Auth (API REST, sin librerías extra).
// Las claves de Supabase viven SOLO en el servidor. El navegador solo recibe cookies protegidas
// (HttpOnly: no las puede leer ningún script; SameSite=Strict: no viajan desde otros sitios).

export type Cfg = { url: string; anon: string };
export type UsuarioAuth = { id: string; email: string };
export type Tokens = { access: string; refresh: string; expiraEn: number };
type F = typeof fetch;
export const COOKIE_ACCESO = "jgl_at";
export const COOKIE_REFRESCO = "jgl_rt";

const cab = (cfg: Cfg, bearer?: string): Record<string, string> => ({
  apikey: cfg.anon,
  "Content-Type": "application/json",
  ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}),
});

type RespuestaToken = { access_token?: string; refresh_token?: string; expires_in?: number; user?: { id?: string; email?: string } };
function leerSesion(d: RespuestaToken): { tokens: Tokens; usuario: UsuarioAuth } | null {
  if (!d.access_token || !d.refresh_token || !d.user?.id) return null;
  return {
    tokens: { access: d.access_token, refresh: d.refresh_token, expiraEn: d.expires_in && d.expires_in > 0 ? d.expires_in : 3600 },
    usuario: { id: d.user.id, email: d.user.email ?? "" },
  };
}

export async function iniciarSesion(cfg: Cfg, email: string, password: string, f: F = fetch) {
  const r = await f(`${cfg.url}/auth/v1/token?grant_type=password`, { method: "POST", headers: cab(cfg), body: JSON.stringify({ email, password }) });
  if (!r.ok) return null;
  return leerSesion((await r.json()) as RespuestaToken);
}

export async function refrescarSesion(cfg: Cfg, refresh: string, f: F = fetch) {
  const r = await f(`${cfg.url}/auth/v1/token?grant_type=refresh_token`, { method: "POST", headers: cab(cfg), body: JSON.stringify({ refresh_token: refresh }) });
  if (!r.ok) return null;
  return leerSesion((await r.json()) as RespuestaToken);
}

// Pregunta a Supabase quién es el dueño del token (no se confía en lo que diga el navegador).
export async function usuarioDeToken(cfg: Cfg, access: string, f: F = fetch): Promise<UsuarioAuth | null> {
  const r = await f(`${cfg.url}/auth/v1/user`, { headers: cab(cfg, access) });
  if (!r.ok) return null;
  const d = (await r.json()) as { id?: string; email?: string };
  return d.id ? { id: d.id, email: d.email ?? "" } : null;
}

export async function cerrarSesion(cfg: Cfg, access: string, f: F = fetch): Promise<void> {
  try { await f(`${cfg.url}/auth/v1/logout`, { method: "POST", headers: cab(cfg, access) }); } catch { /* mejor esfuerzo */ }
}

export function leerCookies(cabecera: string | null): Record<string, string> {
  const salida: Record<string, string> = {};
  for (const par of (cabecera ?? "").split(";")) {
    const i = par.indexOf("=");
    if (i < 1) continue;
    try { salida[par.slice(0, i).trim()] = decodeURIComponent(par.slice(i + 1).trim()); } catch { /* cookie dañada: se ignora */ }
  }
  return salida;
}

export const cookieSesion = (nombre: string, valor: string, maxAgeSeg: number) =>
  `${nombre}=${encodeURIComponent(valor)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${Math.floor(maxAgeSeg)}`;
export const cookieBorrar = (nombre: string) => `${nombre}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
export const cookiesDeTokens = (t: Tokens) => [cookieSesion(COOKIE_ACCESO, t.access, t.expiraEn), cookieSesion(COOKIE_REFRESCO, t.refresh, 60 * 60 * 24 * 7)];
