import { test } from "node:test";
import assert from "node:assert/strict";
import { cookieBorrar, cookieSesion, cookiesDeTokens, iniciarSesion, leerCookies, refrescarSesion, usuarioDeToken } from "./admin-auth.ts";

const cfg = { url: "https://x.supabase.co", anon: "ANON" };
const resp = (ok: boolean, cuerpo: unknown) => ({ ok, json: async () => cuerpo }) as Response;

test("iniciarSesion llama al endpoint correcto con apikey y devuelve tokens", async () => {
  let visto: { url: string; init?: RequestInit } | null = null;
  const f = (async (url: string, init?: RequestInit) => { visto = { url, init }; return resp(true, { access_token: "A", refresh_token: "R", expires_in: 1800, user: { id: "u1", email: "a@b.c" } }); }) as unknown as typeof fetch;
  const s = await iniciarSesion(cfg, "a@b.c", "clave", f);
  assert.equal(visto!.url, "https://x.supabase.co/auth/v1/token?grant_type=password");
  assert.equal((visto!.init!.headers as Record<string, string>).apikey, "ANON");
  assert.equal(s?.usuario.id, "u1");
  assert.equal(s?.tokens.expiraEn, 1800);
});

test("credenciales incorrectas o respuesta incompleta devuelven null", async () => {
  assert.equal(await iniciarSesion(cfg, "a", "b", (async () => resp(false, {})) as unknown as typeof fetch), null);
  assert.equal(await iniciarSesion(cfg, "a", "b", (async () => resp(true, { access_token: "A" })) as unknown as typeof fetch), null);
});

test("usuarioDeToken usa Bearer y valida con Supabase", async () => {
  let auth = "";
  const f = (async (_u: string, init?: RequestInit) => { auth = (init!.headers as Record<string, string>).Authorization; return resp(true, { id: "u9", email: "z@z.z" }); }) as unknown as typeof fetch;
  assert.deepEqual(await usuarioDeToken(cfg, "TOK", f), { id: "u9", email: "z@z.z" });
  assert.equal(auth, "Bearer TOK");
  assert.equal(await usuarioDeToken(cfg, "MALO", (async () => resp(false, {})) as unknown as typeof fetch), null);
});

test("refrescarSesion envía el refresh token", async () => {
  let cuerpo = "";
  const f = (async (_u: string, init?: RequestInit) => { cuerpo = String(init!.body); return resp(true, { access_token: "A2", refresh_token: "R2", user: { id: "u1" } }); }) as unknown as typeof fetch;
  const s = await refrescarSesion(cfg, "R1", f);
  assert.equal(JSON.parse(cuerpo).refresh_token, "R1");
  assert.equal(s?.tokens.access, "A2");
});

test("cookies: HttpOnly, Secure, SameSite=Strict y se leen bien", () => {
  const c = cookieSesion("jgl_at", "a b;c", 3600);
  for (const parte of ["HttpOnly", "Secure", "SameSite=Strict", "Path=/", "Max-Age=3600"]) assert.ok(c.includes(parte), parte);
  assert.equal(c.includes("a b;c"), false); // el valor va codificado
  assert.equal(leerCookies("jgl_at=a%20b%3Bc; otra=1").jgl_at, "a b;c");
  assert.ok(cookieBorrar("jgl_at").includes("Max-Age=0"));
  assert.equal(cookiesDeTokens({ access: "A", refresh: "R", expiraEn: 100 }).length, 2);
  assert.deepEqual(leerCookies(null), {});
});
