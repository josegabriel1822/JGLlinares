// Validación de lo que el panel envía al crear o editar un producto. Función pura (sin base de datos).
export const TIPOS = ["POLO", "POLERA", "ZIPPER", "CASACA"] as const;
export const ESTADOS = ["BORRADOR", "PUBLICADO", "OCULTO"] as const;
export type Tipo = (typeof TIPOS)[number];
export type Estado = (typeof ESTADOS)[number];

export type VarianteValida = { sku: string; talla: string; color: string; colorHex: string; stock: number; activo: boolean };
export type ProductoValido = {
  slug: string; skuBase: string; nombre: string; descripcion: string; tipo: Tipo; estado: Estado; categoria: string;
  destacado: boolean; nuevo: boolean; proximamente: boolean; precioCentimos: number | null; precioPromoCentimos: number | null;
  imagenes: string[]; variantes: VarianteValida[];
};

export const slugificar = (s: string) =>
  s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);

const aCentimos = (x: unknown): number | null | "mal" => {
  if (x === null || x === undefined || x === "") return null;
  if (typeof x !== "number" || !Number.isFinite(x) || x <= 0 || x > 100000) return "mal";
  const c = Math.round(x * 100);
  return Math.abs(x * 100 - c) < 1e-6 ? c : "mal";
};

export function validarProducto(cuerpo: unknown, prefijoFotos: string, categorias: string[]): { ok: true; datos: ProductoValido } | { ok: false; errores: string[] } {
  const e: string[] = [];
  if (typeof cuerpo !== "object" || cuerpo === null || Array.isArray(cuerpo)) return { ok: false, errores: ["Datos inválidos."] };
  const c = cuerpo as Record<string, unknown>;
  const txt = (v: unknown, min: number, max: number) => (typeof v === "string" && v.trim().length >= min && v.trim().length <= max ? v.trim() : null);
  const bool = (v: unknown) => v === true;

  const nombre = txt(c.nombre, 1, 120); if (!nombre) e.push("El nombre es obligatorio (máximo 120 caracteres).");
  const descripcion = typeof c.descripcion === "string" && c.descripcion.length <= 2000 ? c.descripcion.trim() : (e.push("La descripción es demasiado larga (máximo 2000)."), "");
  const tipo = TIPOS.find((t) => t === c.tipo); if (!tipo) e.push("Tipo de prenda inválido.");
  const estado = ESTADOS.find((s) => s === c.estado); if (!estado) e.push("Estado inválido.");
  const categoria = typeof c.categoria === "string" && categorias.includes(c.categoria) ? c.categoria : (e.push("Categoría inválida."), "");
  const skuBase = typeof c.skuBase === "string" && /^[A-Z0-9-]{2,40}$/.test(c.skuBase) ? c.skuBase : (e.push("El SKU base debe tener 2 a 40 letras mayúsculas, números o guiones."), "");
  const slug = nombre ? slugificar(typeof c.slug === "string" && c.slug ? c.slug : nombre) : "";
  if (nombre && slug.length < 2) e.push("No se pudo generar la dirección del producto a partir del nombre.");

  const proximamente = bool(c.proximamente);
  const precio = aCentimos(c.precio), promo = aCentimos(c.precioPromo);
  if (precio === "mal") e.push("El precio debe ser un número positivo con hasta 2 decimales."); 
  if (promo === "mal") e.push("El precio promocional debe ser un número positivo con hasta 2 decimales.");
  if (precio === null && !proximamente && estado === "PUBLICADO") e.push("Un producto publicado necesita precio (o márcalo como próximamente).");
  if (typeof promo === "number" && (typeof precio !== "number" || promo >= precio)) e.push("El precio promocional debe ser menor que el precio regular.");

  const imagenes: string[] = [];
  if (!Array.isArray(c.imagenes) || c.imagenes.length > 8) e.push("Máximo 8 fotos.");
  else for (const u of c.imagenes) {
    if (typeof u !== "string" || !u.startsWith(prefijoFotos) || u.length > 400 || /[\s"'<>]/.test(u)) { e.push("Una de las fotos no es válida: súbela desde el panel."); break; }
    imagenes.push(u);
  }

  const variantes: VarianteValida[] = [];
  if (!Array.isArray(c.variantes) || c.variantes.length > 60) e.push("Máximo 60 variantes.");
  else {
    const skus = new Set<string>(), combos = new Set<string>();
    c.variantes.forEach((v, i) => {
      const n = i + 1;
      if (typeof v !== "object" || v === null) { e.push(`Variante ${n}: datos inválidos.`); return; }
      const r = v as Record<string, unknown>;
      const talla = typeof r.talla === "string" && /^[A-Za-z0-9]{1,8}$/.test(r.talla.trim()) ? r.talla.trim().toUpperCase() : null;
      const color = txt(r.color, 1, 40);
      const hex = typeof r.colorHex === "string" && /^#[0-9a-fA-F]{6}$/.test(r.colorHex) ? r.colorHex.toLowerCase() : null;
      const sku = typeof r.sku === "string" && /^[A-Z0-9-]{3,100}$/.test(r.sku) ? r.sku : null;
      const stock = typeof r.stock === "number" && Number.isInteger(r.stock) && r.stock >= 0 && r.stock <= 100000 ? r.stock : null;
      if (!talla) e.push(`Variante ${n}: talla inválida.`);
      if (!color) e.push(`Variante ${n}: falta el color.`);
      if (!hex) e.push(`Variante ${n}: el color debe ser un código como #0a0a0a.`);
      if (!sku) e.push(`Variante ${n}: SKU inválido (mayúsculas, números y guiones).`);
      if (stock === null) e.push(`Variante ${n}: el stock debe ser un número entero de 0 o más.`);
      if (!talla || !color || !hex || !sku || stock === null) return;
      if (skus.has(sku)) e.push(`Variante ${n}: el SKU ${sku} está repetido.`);
      const combo = `${talla}|${color.toLowerCase()}`;
      if (combos.has(combo)) e.push(`Variante ${n}: ya existe la talla ${talla} en ${color}.`);
      skus.add(sku); combos.add(combo);
      variantes.push({ sku, talla, color, colorHex: hex, stock, activo: r.activo !== false });
    });
    if (estado === "PUBLICADO" && !proximamente && variantes.filter((x) => x.activo).length === 0) e.push("Un producto publicado necesita al menos una variante activa.");
  }
  if (e.length) return { ok: false, errores: e };
  return {
    ok: true,
    datos: {
      slug, skuBase, nombre: nombre as string, descripcion, tipo: tipo as Tipo, estado: estado as Estado, categoria,
      destacado: bool(c.destacado), nuevo: bool(c.nuevo), proximamente,
      precioCentimos: precio as number | null, precioPromoCentimos: promo as number | null, imagenes, variantes,
    },
  };
}

// Acciones sobre un pedido desde el panel
export const ACCIONES = ["aceptar", "rechazar", "cancelar", "preparando", "enviado", "entregado"] as const;
export type Accion = (typeof ACCIONES)[number];
export function validarAccion(c: unknown): { ok: true; accion: Accion; nota: string | null } | { ok: false } {
  if (typeof c !== "object" || c === null) return { ok: false };
  const { accion, nota } = c as Record<string, unknown>;
  const a = ACCIONES.find((x) => x === accion);
  if (!a) return { ok: false };
  if (nota !== undefined && nota !== null && (typeof nota !== "string" || nota.length > 500)) return { ok: false };
  return { ok: true, accion: a, nota: typeof nota === "string" && nota.trim() ? nota.trim() : null };
}
