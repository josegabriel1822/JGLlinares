import { test } from "node:test";
import assert from "node:assert/strict";
import { hashIp, obtenerIp, origenValido } from "./seguridad.ts";

test("origen: acepta el mismo sitio y rechaza otros", () => {
  assert.equal(origenValido("https://jgl.pe", "jgl.pe"), true);
  assert.equal(origenValido("https://malo.com", "jgl.pe"), false);
  assert.equal(origenValido("no-es-url", "jgl.pe"), false);
  assert.equal(origenValido(null, "jgl.pe"), true);
  assert.equal(origenValido("https://jgl.pe", null), false);
});

test("IP: usa x-real-ip, luego la primera de x-forwarded-for", () => {
  const h = (o: Record<string, string>) => ({ get: (n: string) => o[n] ?? null });
  assert.equal(obtenerIp(h({ "x-real-ip": "1.2.3.4" })), "1.2.3.4");
  assert.equal(obtenerIp(h({ "x-forwarded-for": "5.6.7.8, 9.9.9.9" })), "5.6.7.8");
  assert.equal(obtenerIp(h({})), "desconocida");
});

test("hash: estable, depende de la sal y no contiene la IP", () => {
  const a = hashIp("1.2.3.4", "sal1", "pedidos");
  assert.equal(a, hashIp("1.2.3.4", "sal1", "pedidos"));
  assert.notEqual(a, hashIp("1.2.3.4", "sal2", "pedidos"));
  assert.notEqual(a, hashIp("1.2.3.4", "sal1", "otra-ruta"));
  assert.equal(a.includes("1.2.3.4"), false);
  assert.match(a, /^[0-9a-f]{64}$/);
});
