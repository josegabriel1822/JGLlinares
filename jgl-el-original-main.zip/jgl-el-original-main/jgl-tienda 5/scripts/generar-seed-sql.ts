// Genera database/seed.sql a partir de prisma/seed-data.ts (productos de demostración).
// Uso: npm run db:generar-sql
import { writeFileSync } from "node:fs";
import { CATEGORIAS, PRODUCTOS_SEMILLA } from "../prisma/seed-data.ts";

const q = (s: string) => `'${s.replace(/'/g, "''")}'`;
const n = (v: number | null) => (v == null ? "NULL" : String(v));
const b = (v: boolean) => (v ? "true" : "false");
const out: string[] = [
  "-- Productos de DEMOSTRACIÓN. Ejecuta esto después de schema.sql.",
  "-- Es seguro repetirlo: no pisa filas que ya existan.",
  "BEGIN;",
];

for (const c of CATEGORIAS) {
  out.push(`INSERT INTO "Categoria" ("id","slug","nombre") VALUES (${q("cat_" + c.slug)},${q(c.slug)},${q(c.nombre)}) ON CONFLICT DO NOTHING;`);
}
for (const p of PRODUCTOS_SEMILLA) {
  const pid = "prod_" + p.slug;
  out.push(
    `INSERT INTO "Producto" ("id","slug","skuBase","nombre","descripcion","tipo","estado","destacado","nuevo","proximamente","precioCentimos","precioPromoCentimos","imagenes","categoriaId") VALUES ` +
      `(${q(pid)},${q(p.slug)},${q(p.skuBase)},${q(p.nombre)},${q(p.descripcion)},${q(p.tipo)},${q(p.estado)},${b(p.destacado)},${b(p.nuevo)},${b(p.proximamente)},${n(p.precioCentimos)},${n(p.precioPromoCentimos)},'{}',${q("cat_" + p.categoria)}) ON CONFLICT DO NOTHING;`,
  );
  for (const v of p.variantes) {
    out.push(
      `INSERT INTO "Variante" ("id","productoId","talla","color","colorHex","sku","stock","reservado") VALUES ` +
        `(${q("var_" + v.sku.toLowerCase())},${q(pid)},${q(v.talla)},${q(v.color)},${q(v.colorHex)},${q(v.sku)},${v.stock},0) ON CONFLICT DO NOTHING;`,
    );
  }
}
out.push("COMMIT;", "");
writeFileSync(new URL("../database/seed.sql", import.meta.url), out.join("\n"));
console.log("database/seed.sql generado.");
