# JGL — tienda (etapa A terminada; etapa B pendiente)

## Estado
- **Etapa A (hecha): tienda visual y funcional** en `storefront/jgl.html`: sistema global de animaciones, buscador, categorías,
  stock por talla y color, carrito y flujo «FINALIZAR PEDIDO POR WHATSAPP». Probada con un navegador real (55 comprobaciones).
- **Etapa B1 (escrita; la base de datos probada por el usuario en Supabase):** lógica de pedidos e inventario en la base
  (`database/pedidos.sql`, prueba `pruebas.sql`), límite de solicitudes (`database/limite.sql`) y el endpoint
  `src/app/api/pedidos/route.ts`. El endpoint **no se ha ejecutado nunca**: necesita publicar la tienda con la base conectada.
- **Etapa B2 (escrita; pantalla probada con un navegador real contra un servidor de simulación):** panel privado en `/admin`
  (`storefront/admin.html` + `src/app/api/admin/*`): inicio de sesión con Supabase Auth, pedidos (aceptar, rechazar, cancelar,
  preparando, enviado, entregado), productos (precios, promoción, estado, variantes con stock por talla y color), subida de fotos
  validadas e historial de inventario. **Las rutas del servidor nunca se han ejecutado contra Supabase real.**
- **Sin pagos con tarjeta.** Culqi queda en pausa.

## Qué se probó y qué no
- Probado: lógica del catálogo (`npm test`, 21 pruebas: catálogo, validación de pedidos y utilidades de seguridad); el SQL (`database/schema.sql` + `seed.sql`) en SQLite con una traducción mecánica
  (reglas de stock, precios y promociones); y la tienda con Chromium (escritorio, móvil, teclado, movimiento reducido).
- **Sin probar:** el endpoint de pedidos, la instalación de paquetes, el servidor Next.js, la conexión a la base de datos,
  Supabase Auth, Storage y cualquier prueba de varias personas comprando a la vez (necesita una base PostgreSQL real).

## Crear la base de datos (elige UNA vía)
**Vía A (simple):** en Supabase o Neon, editor SQL: pega `database/schema.sql` y ejecútalo; luego `database/seed.sql`.
Después: `cp .env.example .env`, pega tu cadena de conexión en `DATABASE_URL` (solo en tu `.env`), `npm install`, `npx prisma generate`.
**Vía B (Prisma):** `npm install`, `npx prisma validate`, `npm run db:migrar`, `npm run db:checks`, `npm run db:semilla`.
No mezcles las dos vías. Si cambias los datos de ejemplo: `npm run db:generar-sql`.

## Reglas del inventario (ya en la base de datos)
- Cada talla + color tiene su propio stock. Disponible = stock − reservado. La base impide stock negativo y reservas mayores al stock.
- Añadir al carrito NO toca el stock. Al finalizar (etapa B) se crea una solicitud PENDIENTE que **reserva** unidades por tiempo limitado;
  al **aceptar** el pedido el stock se descuenta; al rechazar, cancelar o vencer la reserva se libera.
- Sin datos personales de clientes en la base: el contacto ocurre en WhatsApp.

## Seguridad ya aplicada
- RLS activado sin políticas públicas en todas las tablas; la tienda accede desde el servidor.
- API pública solo de lectura, solo productos PUBLICADOS, sin datos internos y sin caché.
- Sin columnas de tarjetas. `.env` fuera de Git. Textos de la tienda escapados (XSS). Errores sin detalles internos.

## Riesgos pendientes (se cerrarán en la etapa B)
- Falta autenticación y autorización del panel, límite de solicitudes, validación de archivos subidos y registro de acciones.
- Falta probar la reserva de la última unidad con conexiones simultáneas en PostgreSQL.
- Las políticas (envíos, cambios, privacidad…) son texto pendiente; revísalas con un asesor legal.

## Orden de archivos SQL (en Supabase)
`schema.sql` → `seed.sql` → `pedidos.sql` → `pruebas.sql` (luego `select * from jgl_autoprueba();`) → `limite.sql`
(luego `select jgl_autoprueba_limite();` debe devolver `true,true,true,false,false`).

## Orden extra para el panel
`database/fotos.sql` (crea el bucket de fotos). Después, en Supabase: Authentication > Users > Add user (tu correo y contraseña),
desactiva "Allow new users to sign up", y registra tu usuario como administrador:
`insert into "Administrador"(id, email) select id::text, email from auth.users where email = 'TU-CORREO' on conflict do nothing;`

## Variables de entorno (solo en el servidor; en Vercel, no en GitHub)
`DATABASE_URL`, `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `BUCKET_FOTOS`, `HASH_SALT` (texto aleatorio largo), `RESERVA_HORAS`, `LIMITE_PEDIDOS_POR_HORA`, `TIENDA_MODO_DEMO`.

## Riesgos pendientes del panel
- Sin verificación en dos pasos (MFA): recomendable activarla antes de publicar.
- Las rutas `/api/admin/*` y la subida de fotos no se han probado con Supabase real; el límite de intentos de login depende de `limite.sql`.
- Sin copias de seguridad propias: revisa las del plan de Supabase.
- Sin revisión de seguridad externa ni pruebas de carga o de compras simultáneas reales.

## Publicar en Vercel (resumen)
1. Sube esta carpeta a un repositorio PRIVADO de GitHub (el archivo `package.json` debe quedar en la raíz del repositorio).
2. En Vercel: Add New > Project > importa el repositorio. Framework: Next.js (se detecta solo).
3. Antes de pulsar Deploy, añade las variables de entorno (ver arriba). `DATABASE_URL` debe ser la cadena **Transaction pooler** de
   Supabase (puerto 6543) con `?pgbouncer=true&connection_limit=1` al final. La conexión directa de Supabase no sirve en Vercel (usa IPv6).
4. Deploy. Si el build falla, copia el error completo del registro de Vercel (sin llaves) y se corrige.
5. Después de publicar: prueba `/api/productos`, el pedido de prueba y `/admin` con tu usuario.
