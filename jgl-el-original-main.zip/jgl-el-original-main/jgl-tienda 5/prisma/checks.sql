-- Reglas de integridad que Prisma no expresa en el esquema (solo para la vía B: Prisma).
-- Se aplican una vez, después de "npm run db:migrar", con: npm run db:checks
ALTER TABLE "Variante" ADD CONSTRAINT variante_stock_no_negativo CHECK (stock >= 0);
ALTER TABLE "Variante" ADD CONSTRAINT variante_reservado_valido CHECK (reservado >= 0 AND reservado <= stock);
ALTER TABLE "Producto" ADD CONSTRAINT producto_precio_positivo CHECK ("precioCentimos" IS NULL OR "precioCentimos" > 0);
ALTER TABLE "Producto" ADD CONSTRAINT producto_promo_valida CHECK ("precioPromoCentimos" IS NULL OR ("precioCentimos" IS NOT NULL AND "precioPromoCentimos" > 0 AND "precioPromoCentimos" < "precioCentimos"));
ALTER TABLE "PedidoItem" ADD CONSTRAINT item_cantidad_positiva CHECK (cantidad > 0);
ALTER TABLE "Pedido" ADD CONSTRAINT pedido_subtotal_no_negativo CHECK ("subtotalCentimos" >= 0);
