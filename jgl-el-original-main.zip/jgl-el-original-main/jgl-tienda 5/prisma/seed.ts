// Carga el catálogo de demostración. Es seguro repetirlo: NO pisa precios ni stock ya existentes.
import { PrismaClient } from "@prisma/client";
import { CATEGORIAS, PRODUCTOS_SEMILLA } from "./seed-data.ts";

const db = new PrismaClient();

async function main() {
  for (const c of CATEGORIAS) {
    await db.categoria.upsert({ where: { slug: c.slug }, update: {}, create: c });
  }
  for (const p of PRODUCTOS_SEMILLA) {
    const categoria = await db.categoria.findUniqueOrThrow({ where: { slug: p.categoria } });
    const { variantes, categoria: _omitida, ...datos } = p;
    const producto = await db.producto.upsert({
      where: { slug: p.slug },
      update: {},
      create: { ...datos, categoriaId: categoria.id, imagenes: [] },
    });
    for (const v of variantes) {
      await db.variante.upsert({ where: { sku: v.sku }, update: {}, create: { ...v, productoId: producto.id } });
    }
  }
  console.log(`Listo: ${CATEGORIAS.length} categorías y ${PRODUCTOS_SEMILLA.length} productos de demostración.`);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
