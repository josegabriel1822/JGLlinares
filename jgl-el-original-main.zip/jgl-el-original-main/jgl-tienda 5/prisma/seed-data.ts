// Datos de DEMOSTRACIÓN (los mismos de la web de ejemplo). Se reemplazan por tu catálogo real desde el panel.
export type VarianteSemilla = { talla: string; color: string; colorHex: string; sku: string; stock: number };
export type ProductoSemilla = {
  slug: string; skuBase: string; nombre: string; descripcion: string; tipo: "POLO" | "POLERA" | "ZIPPER" | "CASACA";
  estado: "PUBLICADO"; destacado: boolean; nuevo: boolean; proximamente: boolean; categoria: string;
  precioCentimos: number | null; precioPromoCentimos: number | null; variantes: VarianteSemilla[];
};

export const CATEGORIAS = [
  { slug: "polos", nombre: "Polos" },
  { slug: "poleras", nombre: "Poleras" },
  { slug: "zippers", nombre: "Zippers" },
  { slug: "casacas", nombre: "Casacas" },
];

const DESC = "Descripción de ejemplo: reemplaza este texto con los materiales, el corte y los detalles reales de la prenda.";
const N = { nombre: "Negro", hex: "#0a0a0a" }, M = { nombre: "Marfil", hex: "#e9e0cc" }, G = { nombre: "Gris piedra", hex: "#8a867c" };
const TALLAS = ["S", "M", "L", "XL"];
const soles = (n: number) => Math.round(n * 100);
const sku = (slug: string, t: string, c: string) => `${slug}-${t}-${c}`.toUpperCase().replace(/\s+/g, "-");

type Col = { nombre: string; hex: string };
function producto(
  slug: string, nombre: string, categoria: string, tipo: ProductoSemilla["tipo"], precio: number, promo: number | null,
  colores: [Col, number[]][], extra: Partial<Pick<ProductoSemilla, "destacado" | "nuevo">> = {},
): ProductoSemilla {
  return {
    slug, skuBase: slug.toUpperCase(), nombre, descripcion: DESC, tipo, estado: "PUBLICADO", categoria,
    destacado: extra.destacado ?? false, nuevo: extra.nuevo ?? false, proximamente: false,
    precioCentimos: soles(precio), precioPromoCentimos: promo == null ? null : soles(promo),
    // Cada combinación talla + color tiene su propio stock.
    variantes: colores.flatMap(([c, st]) => TALLAS.map((t, i) => ({ talla: t, color: c.nombre, colorHex: c.hex, sku: sku(slug, t, c.nombre), stock: st[i] }))),
  };
}

export const PRODUCTOS_SEMILLA: ProductoSemilla[] = [
  producto("polo-premium-a", "Polo premium A", "polos", "POLO", 129, null, [[N, [2, 5, 3, 0]], [M, [4, 6, 0, 2]], [G, [1, 3, 2, 1]]], { destacado: true }),
  producto("polo-premium-b", "Polo premium B", "polos", "POLO", 139, 119, [[M, [4, 5, 5, 2]], [N, [0, 2, 3, 1]]], { destacado: true, nuevo: true }),
  producto("polo-premium-c", "Polo premium C", "polos", "POLO", 129, 99, [[M, [2, 3, 0, 4]], [G, [0, 1, 2, 0]]]),
  producto("polera-a", "Polera A", "poleras", "POLERA", 189, 149, [[N, [3, 6, 6, 4]], [G, [1, 0, 2, 3]]], { destacado: true }),
  producto("polera-b", "Polera B", "poleras", "POLERA", 199, null, [[M, [0, 0, 0, 0]]]),
  producto("polera-c", "Polera C", "poleras", "POLERA", 169, 129, [[N, [1, 2, 2, 0]], [G, [0, 1, 0, 0]]]),
  producto("zipper-a", "Zipper A", "zippers", "ZIPPER", 249, 199, [[N, [2, 4, 4, 1]], [M, [3, 0, 2, 2]]], { destacado: true }),
  producto("zipper-b", "Zipper B", "zippers", "ZIPPER", 229, null, [[N, [2, 3, 3, 2]]]),
  producto("casaca-a", "Casaca A", "casacas", "CASACA", 329, 259, [[G, [3, 3, 3, 3]], [N, [2, 4, 1, 0]]], { destacado: true, nuevo: true }),
  producto("casaca-b", "Casaca B", "casacas", "CASACA", 359, null, [[N, [1, 2, 2, 1]]]),
  {
    slug: "proximo-1", skuBase: "PROXIMO-1", nombre: "Próximo lanzamiento", categoria: "poleras", tipo: "POLERA", estado: "PUBLICADO",
    descripcion: "Estamos preparando algo nuevo. Escríbenos por WhatsApp y te avisamos cuando esté disponible.",
    destacado: false, nuevo: true, proximamente: true, precioCentimos: null, precioPromoCentimos: null, variantes: [],
  },
];
