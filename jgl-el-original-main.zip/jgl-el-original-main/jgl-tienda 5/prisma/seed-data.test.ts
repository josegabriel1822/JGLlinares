import { test } from "node:test";
import assert from "node:assert/strict";
import { CATEGORIAS, PRODUCTOS_SEMILLA } from "./seed-data.ts";

test("slugs, SKU base y SKUs de variante son únicos", () => {
  const slugs = PRODUCTOS_SEMILLA.map((p) => p.slug);
  assert.equal(new Set(slugs).size, slugs.length);
  const bases = PRODUCTOS_SEMILLA.map((p) => p.skuBase);
  assert.equal(new Set(bases).size, bases.length);
  const skus = PRODUCTOS_SEMILLA.flatMap((p) => p.variantes.map((v) => v.sku));
  assert.equal(new Set(skus).size, skus.length);
});

test("precios enteros en céntimos y promociones menores al precio regular", () => {
  for (const p of PRODUCTOS_SEMILLA) {
    if (p.precioCentimos != null) assert.ok(Number.isInteger(p.precioCentimos) && p.precioCentimos > 0, p.slug);
    if (p.precioPromoCentimos != null) assert.ok(p.precioPromoCentimos > 0 && p.precioPromoCentimos < (p.precioCentimos ?? 0), p.slug);
  }
});

test("stock entero y no negativo, independiente por variante", () => {
  for (const p of PRODUCTOS_SEMILLA) for (const v of p.variantes) assert.ok(Number.isInteger(v.stock) && v.stock >= 0, v.sku);
  const polo = PRODUCTOS_SEMILLA.find((p) => p.slug === "polo-premium-a")!;
  const get = (t: string, c: string) => polo.variantes.find((v) => v.talla === t && v.color === c)!.stock;
  assert.equal(get("M", "Negro"), 5);
  assert.notEqual(get("M", "Negro"), get("M", "Marfil"));
});

test("cada producto apunta a una categoría existente", () => {
  const cats = new Set(CATEGORIAS.map((c) => c.slug));
  for (const p of PRODUCTOS_SEMILLA) assert.ok(cats.has(p.categoria), p.slug);
});

test("los productos vendibles tienen precio y variantes; los próximos no", () => {
  for (const p of PRODUCTOS_SEMILLA) {
    if (p.proximamente) { assert.equal(p.precioCentimos, null); assert.equal(p.variantes.length, 0); }
    else assert.ok(p.precioCentimos != null && p.variantes.length > 0, p.slug);
  }
});
